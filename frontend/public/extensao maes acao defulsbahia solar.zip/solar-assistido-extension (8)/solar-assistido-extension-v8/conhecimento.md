Perfeito — isso não é detalhe estético, isso muda a **arquitetura da extensão**.

Vou retificar o relatório já no padrão correto para implementação real.

---

# 📦 1. MUDANÇA ESTRUTURAL (CRÍTICA)

A extensão **NÃO será popup**.

Ela será:

```text
SIDE PANEL (barra lateral fixa)
```

## Por quê isso importa

Popup:

* perde estado ao fechar ❌
* ruim para fluxos longos ❌
* não suporta upload complexo ❌

Side Panel:

* mantém estado ✔️
* permite fluxo multi-etapas ✔️
* permite drag & drop de arquivos ✔️
* ideal para integração com sistemas (SOLAR) ✔️

---

# 🧱 2. ARQUITETURA ATUALIZADA

## Estrutura de arquivos

```text
/solar-extension/
│
├── manifest.json
├── background.js
├── content.js
├── injected.js
│
├── sidepanel/
│   ├── sidepanel.html
│   ├── sidepanel.js
│   ├── sidepanel.css
│
├── core/
│   ├── parser.js
│   ├── normalizer.js
│   ├── validator.js
│   ├── solar-api.js
│   ├── assistido.js
│   ├── atendimento.js
│   ├── documentos.js
│
├── utils/
│   ├── dom.js
│   ├── events.js
│   ├── csrf.js
│   ├── file-handler.js
│
└── config.js
```

---

# ⚙️ 3. MANIFEST (MULTINAVEGADOR)

## Padrão WebExtension (Chrome + Edge + Brave)

```json
{
  "manifest_version": 3,
  "name": "SOLAR Assistido Manager",
  "version": "1.0",
  "permissions": [
    "scripting",
    "activeTab",
    "storage",
    "tabs"
  ],
  "host_permissions": [
    "https://solar.defensoria.ba.def.br/*"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "side_panel": {
    "default_path": "sidepanel/sidepanel.html"
  }
}
```

---

## Compatibilidade Firefox

Firefox ainda não usa `side_panel` igual Chrome.

Fallback:

```text
usar janela lateral simulada (window.open fixo)
OU
usar extensão com aba fixa
```

👉 recomendação prática:

```text
priorizar Chrome/Edge → depois adaptar Firefox
```

---

# 🎨 4. DESIGN SYSTEM (LILÁS MODERNO)

## Paleta principal

```css
:root {
  --primary: #7C3AED;       /* lilás principal */
  --primary-light: #A78BFA;
  --secondary: #F97316;     /* laranja suave */
  --background: #F9FAFB;
  --card: #FFFFFF;
  --text: #1F2937;
  --border: #E5E7EB;
}
```

---

## Layout do Side Panel

```text
┌──────────────────────────┐
│ Header (logo + título)   │
├──────────────────────────┤
│ Upload JSON              │
│ Upload arquivos          │
├──────────────────────────┤
│ Dados normalizados       │
├──────────────────────────┤
│ Etapas (wizard)          │
│ 1. CPF                   │
│ 2. Cadastro              │
│ 3. Docs pessoais         │
│ 4. Atendimento           │
│ 5. Docs atendimento      │
├──────────────────────────┤
│ Console de execução      │
├──────────────────────────┤
│ Botão EXECUTAR           │
└──────────────────────────┘
```

---

## Estilo visual

* bordas suaves (`border-radius: 12px`)
* sombra leve
* botões sólidos lilás
* feedback visual por etapa (verde/vermelho)

---

# 🧠 5. FLUXO VISUAL (WIZARD)

## Etapas no painel

```text
[✔] JSON carregado
[✔] Dados normalizados
[ ] CPF validado
[ ] Assistido criado
[ ] Documentos pessoais
[ ] Atendimento
[ ] Docs atendimento
```

---

# 🔁 6. ENGINE DE EXECUÇÃO (ATUALIZADA)

Agora controlada pelo sidepanel:

```text
sidepanel.js
  ↓
background.js
  ↓
injeta content.js
  ↓
content.js executa no SOLAR
```

---

# 🧩 7. INTERAÇÃO SIDE PANEL ↔ SOLAR

## Comunicação

```js
chrome.runtime.sendMessage({
  action: "EXECUTAR_ETAPA",
  etapa: "cadastro_assistido",
  payload: dados
});
```

---

## Execução no content.js

```js
if (msg.etapa === "cadastro_assistido") {
  preencherFormulario(dados);
}
```

---

# 📎 8. UPLOAD DE ARQUIVOS (SIDE PANEL)

## Interface

* drag & drop
* múltiplos arquivos
* associação por tipo

---

## Estrutura interna

```js
{
  tipo: "RG",
  file: File
}
```

---

# 🔐 9. RESTRIÇÃO CRÍTICA (mantida)

Mesmo com sidepanel:

```text
🚨 Upload e cadastro DEVEM ocorrer dentro da aba do SOLAR
```

Nunca no background.

---

# 🧾 10. DOCUMENTOS (DUAS CAMADAS)

## Pessoais

```text
assistido_id obrigatório
```

## Atendimento

```text
atendimento_id obrigatório
```

---

# 🧠 11. RELAÇÃO COM O BI (VISÃO MAIOR)

A extensão sidepanel vira:

```text
CENTRO DE OPERAÇÃO DO SOLAR
```

E se conecta com:

* atendimentos →
* peticionamentos →
* GED
* fases processuais

---

# ⚠️ 12. ERROS (ATUALIZAÇÃO)

## continua válido

* Blocked → requisição fora do contexto
* Angular não sincronizado → não salva
* receiving end → script não injetado

## novo ponto

Sidepanel NÃO elimina isso.

Ele só organiza melhor o fluxo.

---

# 🚀 13. DIFERENCIAL DA VERSÃO FINAL

Antes:

```text
extensão funcional
```

Agora:

```text
ferramenta profissional de operação do SOLAR
```

---

# 🎯 14. CONCLUSÃO RETIFICADA

A extensão ideal agora é:

```text
SIDE PANEL + ENGINE INTERNO + EXECUÇÃO NA PÁGINA
```

Capaz de:

* cadastrar assistido
* anexar documentos pessoais
* criar atendimento
* anexar documentos de atendimento
* manter estado
* permitir operação contínua



