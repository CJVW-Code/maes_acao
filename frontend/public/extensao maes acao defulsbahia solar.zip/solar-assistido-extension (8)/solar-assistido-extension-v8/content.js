(function(){
  if (window.__SOLAR_ASSISTIDO_CONTENT_V8__) return;
  window.__SOLAR_ASSISTIDO_CONTENT_V8__ = true;

  function $(s){ return document.querySelector(s); }
  function onlyDigits(s){ return String(s||'').replace(/\D/g,''); }
  function wait(ms){ return new Promise(r=>setTimeout(r,ms)); }
  function norm(s){ return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim(); }
  function firstValue(){
    for(const value of arguments){
      if(value !== undefined && value !== null && String(value).trim() !== '') return value;
    }
    return '';
  }

  function getCsrf(){
    return document.querySelector('input[name=csrfmiddlewaretoken]')?.value ||
           document.querySelector('#csrf_token')?.value ||
           (document.cookie.match(/csrftoken=([^;]+)/)||[])[1] || '';
  }

  async function consultarCpf(cpf){
    const csrf=getCsrf();
    const payloads = [
      { id: null, cpf: onlyDigits(cpf) },
      { cpf: onlyDigits(cpf) }
    ];
    let last = null;
    for (const body of payloads) {
      try {
        const r=await fetch('/assistido/cpf/existe/',{
          method:'POST',
          credentials:'same-origin',
          headers:{
            'Content-Type':'application/json;charset=UTF-8',
            'Accept':'application/json, text/plain, */*',
            'X-CSRFToken':csrf
          },
          body:JSON.stringify(body)
        });
        const text=await r.text();
        let data; try{ data=JSON.parse(text); }catch(e){ data={raw:text}; }
        last = {ok:r.ok, status:r.status, data};
        if (r.ok) {
          const existe = !!(data && (data.existe || data.id || data.pessoa || data.nome || data.assistido));
          return {ok:true, status:r.status, existe, data};
        }
      } catch (e) {
        last = {ok:false, error:e.message};
      }
    }
    return {ok:false, error:last?.error || 'Endpoint de CPF não respondeu corretamente.', last};
  }

  function getScopeLegacy(){
    const el = document.querySelector('[ng-controller="CadastrarPessoaModel"]') || document.querySelector('#ContentSide') || document.body;
    if(!window.angular) throw new Error('Angular ainda não carregou. Aguarde a página terminar de abrir.');
    const scope = window.angular.element(el).scope();
    if(!scope || !scope.pessoa) throw new Error('Escopo Angular do cadastro ainda não está pronto. Confirme se você está na tela /assistido/editar/.');
    return scope;
  }

  function findPessoaScopeFrom(el){
    if(!el || !window.angular) return null;
    const wrapped = window.angular.element(el);
    let scope = (wrapped.scope && wrapped.scope()) || (wrapped.isolateScope && wrapped.isolateScope());
    while(scope){
      if(scope.pessoa) return scope;
      scope = scope.$parent;
    }
    return null;
  }

  function getScope(){
    if(!window.angular) throw new Error('Angular ainda nÃ£o carregou. Aguarde a pÃ¡gina terminar de abrir.');
    const candidates = [
      '[ng-controller="CadastrarPessoaModel"]',
      '[data-ng-controller="CadastrarPessoaModel"]',
      '#AssistidoForm',
      '#ContentSide',
      '[ng-model^="pessoa."]',
      '[data-ng-model^="pessoa."]',
      '#id_cpf',
      'body'
    ];
    for(const selector of candidates){
      const scope = findPessoaScopeFrom(document.querySelector(selector));
      if(scope) return scope;
    }
    throw new Error('Escopo Angular do cadastro ainda nÃ£o estÃ¡ pronto. Confirme se vocÃª estÃ¡ na tela /assistido/editar/.');
  }

  function cadastroDiagnostics(){
    return {
      href: location.href,
      readyState: document.readyState,
      isCadastroUrl: location.pathname.includes('/assistido/editar/'),
      hasAngular: !!window.angular,
      hasAssistidoForm: !!document.querySelector('#AssistidoForm'),
      hasCpfInput: !!document.querySelector('#id_cpf'),
      hasContentSide: !!document.querySelector('#ContentSide'),
      title: document.title
    };
  }

  function isVisible(el){
    if(!el) return false;
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  function textOf(el){
    return norm(el?.textContent || el?.value || el?.getAttribute('title') || el?.getAttribute('aria-label') || '');
  }

  function dataUrlToFile(item){
    const parts = String(item.dataUrl || '').split(',');
    if(parts.length < 2) throw new Error('Arquivo sem dataUrl valido: '+item.name);
    const meta = parts[0];
    const mime = item.type || (meta.match(/data:([^;]+)/) || [])[1] || 'application/octet-stream';
    const binary = atob(parts[1]);
    const bytes = new Uint8Array(binary.length);
    for(let i=0;i<binary.length;i++) bytes[i] = binary.charCodeAt(i);
    return new File([bytes], item.name || 'arquivo', { type: mime });
  }

  function runInPage(fn, args){
    return Promise.resolve({ok:false, error:'runInPage desativado; use callPageBridge.'});
  }

  function ensurePageBridge(){
    if(document.getElementById('solar-assistido-page-bridge')) return true;
    const script = document.createElement('script');
    script.id = 'solar-assistido-page-bridge';
    script.src = chrome.runtime.getURL('page-bridge.js');
    script.async = false;
    (document.documentElement || document.head || document.body).appendChild(script);
    return true;
  }

  async function callPageBridge(action, payload, timeoutMs = 15000){
    ensurePageBridge();
    await wait(150);
    return new Promise((resolve) => {
      const id = 'solar-ext-' + Date.now() + '-' + Math.random().toString(16).slice(2);
      const timer = setTimeout(() => {
        window.removeEventListener('message', onMessage);
        resolve({ok:false, error:'Tempo esgotado aguardando page bridge: '+action});
      }, timeoutMs);
      function onMessage(event){
        const msg = event.data || {};
        if(event.source !== window || msg.source !== 'solar-assistido-page' || msg.id !== id) return;
        clearTimeout(timer);
        window.removeEventListener('message', onMessage);
        resolve(msg.result || {ok:false, error:'Resposta vazia do page bridge.'});
      }
      window.addEventListener('message', onMessage);
      window.postMessage({source:'solar-assistido-content', id, action, payload}, '*');
    });
  }

  function pagePreencherAngular(data){
    return callPageBridge('fillAngular', data, 20000);
  }

  function pageSalvarAngular(){
    return callPageBridge('saveAngular', {}, 30000);
  }

  function setNativeValue(el, value){
    if(!el) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype :
      el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    desc && desc.set ? desc.set.call(el, value ?? '') : el.value = value ?? '';
    ['input','change','keyup','keydown','blur'].forEach(ev=>el.dispatchEvent(new Event(ev,{bubbles:true})));
    return true;
  }

  function selectByTextOrValue(sel, wanted){
    const el = typeof sel==='string' ? document.querySelector(sel) : sel;
    if(!el || wanted==null) return false;
    if(!el.options) return setNativeValue(el, wanted);
    const w = norm(wanted);
    let found = '';
    for(const opt of el.options){
      const t = norm(opt.textContent||'');
      if(t === w || t.includes(w) || w.includes(t) || String(opt.value)===String(wanted)){ found=opt.value; break; }
    }
    if(found==='') return false;
    setNativeValue(el, found);
    return true;
  }

  function setAnyField(selector, value, textFallback){
    if(value === undefined || value === null) return false;
    let changed = false;
    for(const el of document.querySelectorAll(selector)){
      if(el.tagName === 'SELECT') {
        changed = selectByTextOrValue(el, textFallback ?? value) || setNativeValue(el, value) || changed;
      } else {
        changed = setNativeValue(el, value) || changed;
      }
    }
    return changed;
  }

  function estadoCivilValue(texto){
    const t = norm(texto);
    const select = document.querySelector('#id_estado_civil');
    if(select && t){
      for(const opt of select.options || []){
        const optionText = norm(opt.textContent || '');
        if(optionText === t || optionText.includes(t) || t.includes(optionText)) return opt.value;
      }
    }
    if(t.includes('casad')) return '1';
    if(t.includes('uniao') || t.includes('conviv')) return '6';
    if(t.includes('divorci')) return '3';
    if(t.includes('separad')) return '2';
    if(t.includes('viuv')) return '4';
    if(t.includes('solteir')) return '0';
    return '';
  }

  function isCasadoOuUniao(data){
    const t = norm(data.estado_civil_texto);
    return t.includes('casad') || t.includes('uniao') || t.includes('conviv');
  }

  function setIfPresent(selector, value){
    if(value === undefined || value === null || value === '') return false;
    return setNativeValue(document.querySelector(selector), value);
  }

  function sanitizeInvalidFormValues(){
    const invalid = '? object:null ?';
    const sanitized = [];
    for(const el of document.querySelectorAll('input, textarea, select')){
      if(String(el.value || '').trim() === invalid){
        setNativeValue(el, '');
        sanitized.push(el.name || el.id || el.tagName);
      }
    }
    return sanitized;
  }

  async function postAssistidoForm(form){
    const action = form.getAttribute('action') || location.href.replace('/editar/', '/salvar/');
    const fd = new FormData(form);
    if(!fd.get('next')) fd.set('next', '/atendimento/listar/');
    const r = await fetch(action, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: fd
    });
    const text = await r.text();
    let data;
    try { data = JSON.parse(text); } catch(_) { data = {raw: text}; }
    const success = !!(r.ok && data && (data.success || data.id || data.pessoa?.id));
    return {
      ok: success,
      status: r.status,
      data,
      assistido_id: String(data.id || data.pessoa?.id || ''),
      payloadResumo: {
        cpf: fd.get('cpf') || '',
        nome: fd.get('nome') || '',
        mae0: fd.get('mae0') || '',
        estado_civil: fd.get('estado_civil') || '',
        nacionalidade: fd.get('nacionalidade') || '',
        tipo_trabalho: fd.get('tipo_trabalho') || '',
        profissao: fd.get('profissao') || ''
      }
    };
  }

  function setPessoaDefaults(p, data){
    const estadoCivil = estadoCivilValue(data.estado_civil_texto);
    if(estadoCivil !== '') p.estado_civil = estadoCivil;
    if(norm(data.nacionalidade_texto).includes('brasileir')) p.nacionalidade = '0';
    if(norm(data.tipo_trabalho_texto).includes('benef')) p.tipo_trabalho = '5';

    p.rg_numero = firstValue(data.rg_numero, p.rg_numero);
    p.rg_orgao = firstValue(data.rg_orgao, p.rg_orgao);
    p.rg_data_expedicao = firstValue(data.rg_data_expedicao, p.rg_data_expedicao);
    p.certidao_tipo = firstValue(data.certidao_tipo, p.certidao_tipo);
    p.certidao_numero = firstValue(data.certidao_numero, p.certidao_numero);
    p.raca = firstValue(data.raca, p.raca);
    p.escolaridade = firstValue(data.escolaridade, p.escolaridade);
    p.profissao = firstValue(data.profissao, p.profissao);

    p.cep = firstValue(data.cep, p.cep);
    p.logradouro = firstValue(data.logradouro, p.logradouro);
    p.numero = firstValue(data.numero, p.numero);
    p.complemento = firstValue(data.complemento, p.complemento);
    p.bairro = firstValue(data.bairro, p.bairro);
    p.municipio = firstValue(data.municipio, p.municipio);
    p.estado = firstValue(data.estado, p.estado);
    p.tipo_area = firstValue(data.tipo_area, p.tipo_area, 0);
    p.principal = p.principal ?? true;
    p.tipo = p.tipo ?? 0;

    if(!p.moradia || typeof p.moradia !== 'object') p.moradia = {};
    p.moradia.tipo = firstValue(data.moradia_tipo, p.moradia.tipo, 5);
    p.moradia.num_comodos = firstValue(data.moradia_num_comodos, p.moradia.num_comodos, 0);

    p.numero_membros = Number(firstValue(data.renda_numero_membros, p.numero_membros, 1)) || 1;
    p.numero_membros_economicamente_ativos = Number(firstValue(data.renda_numero_membros_economicamente_ativos, p.numero_membros_economicamente_ativos, 0)) || 0;
    p.ganho_mensal = firstValue(data.renda_individual, p.ganho_mensal, '0.00');
    p.ganho_mensal_membros = firstValue(data.renda_familiar, p.ganho_mensal_membros, '0.00');
    p.tem_plano_saude = firstValue(data.tem_plano_saude, p.tem_plano_saude, 0);
    p.isento_ir = firstValue(data.isento_ir, p.isento_ir, 1);
    p.previdencia = firstValue(data.previdencia, p.previdencia, 0);
    if(!Array.isArray(p.patrimonios)) p.patrimonios = [];

    if(isCasadoOuUniao(data)){
      if(!Array.isArray(p.membros) || !p.membros.length) p.membros = [{id:null,nome:null,parentesco:0,renda:'0.00'}];
      p.membros[0].nome = data.nome_conjuge || p.membros[0].nome || 'desconhecido';
      p.membros[0].parentesco = p.membros[0].parentesco ?? 0;
      p.membros[0].renda = p.membros[0].renda || '0.00';
    }
  }

  function getValue(sel){
    return document.querySelector(sel)?.value || '';
  }

  function validarDom(){
    const cpf = getValue('#id_cpf');
    const nome = getValue('#id_nome');
    const dataNascimento = getValue('#id_data_nascimento');
    const filiacao = getValue('#mae0');
    const telefoneEl = document.querySelector('input[name="telefone"]') ||
      document.querySelector('input[name*="telefone"]') ||
      document.querySelector('input[id*="telefone"]');
    const telefone = telefoneEl?.value || '';
    const faltas = [];
    if(!onlyDigits(cpf)) faltas.push('cpf');
    if(!nome) faltas.push('nome');
    if(!dataNascimento) faltas.push('data_nascimento');
    if(!filiacao) faltas.push('filiacao');
    if(!onlyDigits(telefone)) faltas.push('telefone');
    return {
      ok: faltas.length===0,
      angularDisponivel: false,
      modo: 'dom',
      angularInvalid: [],
      faltas,
      pessoaResumo: {
        cpf,
        nome,
        data_nascimento: dataNascimento,
        filiacao,
        telefone,
        email: getValue('#id_email'),
        estado_civil: getValue('#id_estado_civil'),
        nacionalidade: getValue('#id_nacionalidade')
      }
    };
  }

  async function clickSalvarFallback(){
    const sanitized = sanitizeInvalidFormValues();
    const angular = await pageSalvarAngular();
    if(angular && angular.ok){
      return {
        ...angular,
        sanitized,
        href: location.href,
        mensagem: 'Assistido salvo via Angular/page bridge.'
      };
    }

    const form = document.querySelector('#AssistidoForm') || document.querySelector('form');
    if(form){
      try{
        const resp = await postAssistidoForm(form);
        return {
          ...resp,
          sanitized,
          angular,
          href: location.href,
          mensagem: resp.ok
            ? 'Assistido salvo por POST direto do formulario.'
            : 'O SOLAR recusou o formulario. Veja data/errors e payloadResumo.'
        };
      }catch(e){
        return {ok:false, error:e.message || String(e), sanitized, href:location.href};
      }
    }

    const selectors = [
      'button[type="submit"]',
      'input[type="submit"]',
      '#btn-salvar',
      '.btn-salvar',
      'button[ng-click*="salvar"]',
      'button[data-ng-click*="salvar"]',
      'a[ng-click*="salvar"]',
      'a[data-ng-click*="salvar"]',
      'button[onclick*="salvar"]',
      'a[onclick*="salvar"]'
    ];
    const candidates = [];
    for(const selector of selectors) candidates.push(...document.querySelectorAll(selector));
    const button = candidates.find(el => isVisible(el) && /salvar|gravar|confirmar|cadastrar/i.test(el.textContent || el.value || el.title || el.getAttribute('aria-label') || '')) ||
      candidates.find(isVisible);
    if(button){
      setTimeout(() => button.click(), 80);
      return {ok:true, clicked:true, sanitized, href:location.href, mensagem:'Acionei o botao de salvamento visivel. Confira a tela do SOLAR para mensagens de validacao.'};
    }
    return {ok:false, error:'Nao encontrei botao ou formulario de salvamento visivel.', diagnostico: cadastroDiagnostics()};
  }

  async function waitForCadastroReady(){
    if(!location.pathname.includes('/assistido/editar/')){
      throw new Error('A aba ativa nao esta na tela de cadastro de assistido (/assistido/editar/). URL atual: '+location.href);
    }
    for(let i=0;i<60;i++){
      if (document.querySelector('#id_cpf')) return true;
      await wait(500);
    }
    throw new Error('A tela de cadastro nao ficou pronta a tempo. Diagnostico: '+JSON.stringify(cadastroDiagnostics()));
  }

  async function preencherBasico(data){
    await waitForCadastroReady();
    const tab = document.querySelector('#myTab a[href="#basico"]');
    if(tab) tab.click();
    await wait(300);
    let angularPreenchido = false;
    let angularErro = '';

    const pageResp = await pagePreencherAngular(data);
    angularPreenchido = !!(pageResp && pageResp.ok);
    if(!angularPreenchido) angularErro = pageResp?.error || 'Preenchimento Angular no contexto da pagina falhou.';

    await wait(400);
    setNativeValue($('#id_cpf'), data.cpf_formatado || data.cpf);
    setNativeValue($('#id_nome'), data.nome || '');
    setNativeValue($('#mae0'), data.filiacao || 'DESCONHECIDO');
    setNativeValue($('#id_data_nascimento'), data.data_nascimento || '');
    setNativeValue($('#id_email'), data.email||'');
    const tel = document.querySelector('input[name="telefone"]');
    if(tel) setNativeValue(tel, data.telefone_formatado || data.telefone || '');
    selectByTextOrValue('#id_estado_civil', data.estado_civil_texto || 'Solteiro');
    selectByTextOrValue('#id_nacionalidade', data.nacionalidade_texto || 'Brasileiro');
    selectByTextOrValue('#id_tipo_trabalho', data.tipo_trabalho_texto || 'Beneficiário');

    const estadoCivilCod = estadoCivilValue(data.estado_civil_texto);
    setAnyField('#id_estado_civil, select[name="estado_civil"], input[name="estado_civil"]', estadoCivilCod || '', data.estado_civil_texto || 'Solteiro');
    setAnyField('#id_nacionalidade, select[name="nacionalidade"], input[name="nacionalidade"]', norm(data.nacionalidade_texto).includes('brasileir') ? '0' : '', data.nacionalidade_texto || 'Brasileiro');
    setAnyField('#id_tipo_trabalho, select[name="tipo_trabalho"], input[name="tipo_trabalho"]', norm(data.tipo_trabalho_texto).includes('benef') ? '5' : '', data.tipo_trabalho_texto || 'Beneficiario');
    setAnyField('#id_profissao, input[name="profissao"], input[id*="profissao"]', data.profissao || '');
    setAnyField('#id_genero, select[name="genero"], input[name="genero"]', '');
    setAnyField('#id_doenca_grave, select[name="doenca_grave"], input[name="doenca_grave"]', '');
    setAnyField('#id_orientacao_sexual, select[name="orientacao_sexual"], input[name="orientacao_sexual"]', '');
    setAnyField('#id_identidade_genero, select[name="identidade_genero"], input[name="identidade_genero"]', '');
    setAnyField('#id_certidao_tipo, select[name="certidao_tipo"], input[name="certidao_tipo"]', data.certidao_tipo || '');
    setAnyField('#id_raca, select[name="raca"], input[name="raca"]', data.raca || '');
    setAnyField('#id_escolaridade, select[name="escolaridade"], input[name="escolaridade"]', data.escolaridade || '');
    sanitizeInvalidFormValues();

    setIfPresent('#id_rg_numero, input[name="rg_numero"]', data.rg_numero);
    setIfPresent('#id_rg_orgao, input[name="rg_orgao"]', data.rg_orgao);
    setIfPresent('#id_rg_data_expedicao, input[name="rg_data_expedicao"]', data.rg_data_expedicao);
    setIfPresent('#id_cep, input[name="cep"], input[id*="cep"], input[name*="cep"]', data.cep);
    setIfPresent('#id_logradouro, input[name="logradouro"], input[id*="logradouro"], input[name*="logradouro"], input[id*="endereco"], input[name*="endereco"]', data.logradouro);
    setIfPresent('#id_numero, input[name="numero"], input[id*="numero"], input[name*="numero"]', data.numero);
    setIfPresent('#id_complemento, input[name="complemento"], input[id*="complemento"], input[name*="complemento"]', data.complemento);
    setIfPresent('#id_bairro, input[name="bairro"], input[id*="bairro"], input[name*="bairro"]', data.bairro);
    setIfPresent('#id_municipio, input[name="municipio"], input[id*="municipio"], input[name*="municipio"]', data.municipio_nome || data.municipio);
    setIfPresent('#id_estado, input[name="estado"], input[id*="estado"], input[name*="estado"]', data.estado_nome || data.estado);
    if(isCasadoOuUniao(data)){
      setIfPresent('#id_nome_conjuge, input[name="nome_conjuge"], input[name*="conjuge"], input[id*="conjuge"], input[name*="membro"], input[id*="membro"]', data.nome_conjuge || 'desconhecido');
    }

    try { if(window.validTab) window.validTab(); } catch(e) {}
    const resultado = validar();
    resultado.angularPreenchido = angularPreenchido;
    resultado.enderecoRecebido = !!(data.cep || data.logradouro || data.bairro || data.municipio || data.estado);
    if(pageResp && pageResp.enderecos !== undefined) resultado.enderecosAngular = pageResp.enderecos;
    if(angularErro) resultado.angularErro = angularErro;
    return resultado;
  }

  async function salvarAssistido(){
    if(!location.pathname.includes('/assistido/editar/')){
      return {ok:false, error:'A aba ativa nao esta na tela de cadastro de assistido.', diagnostico: cadastroDiagnostics()};
    }

    const fallback = await clickSalvarFallback();
    if(fallback.ok) return fallback;

    return {
      ok:false,
      error: fallback.error || 'Nao foi possivel salvar o assistido.',
      fallback,
      diagnostico: cadastroDiagnostics()
    };
  }

  async function injetarArquivosAtual(files){
    if(!Array.isArray(files) || !files.length){
      return {ok:false, error:'Nenhum arquivo recebido para injecao.'};
    }
    const inputs = Array.from(document.querySelectorAll('input[type="file"]')).filter(isVisible);
    if(!inputs.length){
      return {ok:false, error:'Nao encontrei input[type=file] visivel na tela atual.', diagnostico: cadastroDiagnostics()};
    }
    const input = inputs.find(el => el.multiple) || inputs[0];
    const dt = new DataTransfer();
    const accepted = input.multiple ? files : files.slice(0, 1);
    for(const item of accepted) dt.items.add(dataUrlToFile(item));
    input.files = dt.files;
    ['input','change','blur'].forEach(ev => input.dispatchEvent(new Event(ev, {bubbles:true})));
    await wait(500);
    return {
      ok: true,
      inputMultiple: !!input.multiple,
      recebidos: files.length,
      injetados: accepted.length,
      nomes: accepted.map(f => f.name)
    };
  }

  function getAtendimentoNumero(){
    const m = location.pathname.match(/\/atendimento\/(\d+)/);
    return m ? m[1] : '';
  }

  function getAssistidoIdFromUrl(){
    const m = location.pathname.match(/\/assistido\/editar\/(\d+)/);
    return m && m[1] !== '0' ? m[1] : '';
  }

  function clickDocumentosAssistidoTab(){
    const clicked = clickByText('a, button, li', ['documentos', 'docs']);
    return !!clicked;
  }

  function shortAttr(el, name){
    return (el.getAttribute(name) || '').slice(0, 240);
  }

  function diagnosticarDocumentosAssistido(){
    const interesting = /(document|arquivo|anexo|ged|assistido|pessoa|upload)/i;
    const forms = Array.from(document.querySelectorAll('form')).map((form, index) => ({
      index,
      visible: isVisible(form),
      id: form.id || '',
      className: form.className || '',
      action: form.getAttribute('action') || '',
      method: form.getAttribute('method') || '',
      enctype: form.getAttribute('enctype') || '',
      text: (form.innerText || '').trim().slice(0, 300),
      fields: Array.from(form.querySelectorAll('input, select, textarea')).slice(0, 40).map(el => ({
        tag: el.tagName,
        type: el.getAttribute('type') || '',
        name: el.getAttribute('name') || '',
        id: el.id || '',
        value: String(el.value || '').slice(0, 80),
        visible: isVisible(el)
      }))
    }));
    const inputsFile = Array.from(document.querySelectorAll('input[type="file"]')).map((el, index) => ({
      index,
      visible: isVisible(el),
      name: el.name || '',
      id: el.id || '',
      multiple: !!el.multiple,
      accept: el.accept || '',
      formAction: el.form?.getAttribute('action') || '',
      formId: el.form?.id || ''
    }));
    const links = Array.from(document.querySelectorAll('a, button')).filter(el => {
      const blob = [el.innerText, el.value, el.title, el.getAttribute('href'), el.getAttribute('ng-click'), el.getAttribute('data-ng-click'), el.getAttribute('onclick')].join(' ');
      return interesting.test(blob);
    }).slice(0, 80).map(el => ({
      tag: el.tagName,
      visible: isVisible(el),
      text: (el.innerText || el.value || '').trim().slice(0, 120),
      href: shortAttr(el, 'href'),
      ngClick: shortAttr(el, 'ng-click') || shortAttr(el, 'data-ng-click'),
      onclick: shortAttr(el, 'onclick'),
      id: el.id || '',
      className: String(el.className || '').slice(0, 120)
    }));
    const scripts = Array.from(document.scripts).map(s => s.src || s.textContent || '').filter(s => interesting.test(s)).slice(0, 20).map(s => s.slice(0, 500));
    return {
      href: location.href,
      title: document.title,
      hash: location.hash,
      forms,
      inputsFile,
      links,
      scripts
    };
  }

  async function injetarArquivosEmInputVisivel(files){
    clickDocumentosAssistidoTab();
    await wait(500);
    const inputs = Array.from(document.querySelectorAll('input[type="file"]')).filter(isVisible);
    if(!inputs.length) return {ok:false, error:'Nao encontrei input de arquivo visivel para documentos pessoais.'};
    const input = inputs.find(el => el.multiple) || inputs[0];
    const dt = new DataTransfer();
    const accepted = input.multiple ? files : files.slice(0, 1);
    for(const item of accepted) dt.items.add(dataUrlToFile(item));
    input.files = dt.files;
    ['input','change','blur'].forEach(ev => input.dispatchEvent(new Event(ev, {bubbles:true})));
    return {
      ok:true,
      modo:'input_visivel',
      inputMultiple: !!input.multiple,
      recebidos: files.length,
      injetados: accepted.length,
      nomes: accepted.map(f => f.name),
      mensagem:'Arquivos colocados no campo de documentos pessoais. Se o SOLAR exigir confirmar/salvar na tela, confira visualmente.'
    };
  }

  async function getTiposDocumentoPessoal(){
    const urls = [
      '/api/v1/tipos-documento.json?ativo=true&exibir_em_documento_assistido=true',
      '/api/v1/tipos-documento.json?ativo=true&exibir_em_documento_pessoa=true',
      '/api/v1/tipos-documento.json?ativo=true'
    ];
    for(const url of urls){
      try{
        const r = await fetch(url, {credentials:'same-origin', headers:{'Accept':'application/json, text/plain, */*'}});
        if(!r.ok) continue;
        const data = await r.json();
        const results = data.results || data;
        if(Array.isArray(results) && results.length) return results;
      }catch(_){}
    }
    return [];
  }

  async function uploadDocumentoAssistidoDireto(assistidoId, item, tipos){
    const file = dataUrlToFile(item);
    const endpoints = [
      `/assistido/documento/salvar/${assistidoId}/`,
      `/assistido/documentos/salvar/${assistidoId}/`,
      `/assistido/${assistidoId}/documentos/adicionar/`,
      `/assistido/${assistidoId}/documento/adicionar/`,
      `/assistido/${assistidoId}/documento/salvar/`,
      `/assistido/${assistidoId}/documentos/salvar/`,
      `/assistido/${assistidoId}/documento/salvar/false`,
      `/assistido/documento/salvar/`,
      `/ged/assistido/${assistidoId}/documento/salvar/`,
      `/ged/documento/salvar/`,
      `/documento/assistido/salvar/`,
      `/documentos/assistido/salvar/`
    ];
    const erros = [];
    for(const url of endpoints){
      const fd = new FormData();
      fd.append('nome', (item.name || file.name || 'documento').replace(/\.[^.]+$/, ''));
      fd.append('documento', String(tipoDocumentoParaArquivo(item, tipos)));
      fd.append('arquivo', file, file.name);
      fd.append('assistido', String(assistidoId));
      fd.append('pessoa', String(assistidoId));
      fd.append('pessoa_id', String(assistidoId));
      fd.append('assistido_id', String(assistidoId));
      try{
        const r = await fetch(url, {
          method:'POST',
          credentials:'same-origin',
          headers: getCsrf() ? {'X-CSRFToken': getCsrf()} : {},
          body: fd
        });
        const text = await r.text();
        let data;
        try{ data = JSON.parse(text); }catch(_){ data = {raw:text.slice(0, 300)}; }
        const success = r.ok && !(data && data.success === false);
        if(success) return {ok:true, endpoint:url, status:r.status, data};
        erros.push({endpoint:url, status:r.status, data});
      }catch(e){
        erros.push({endpoint:url, erro:e.message || String(e)});
      }
    }
    return {ok:false, nome:item.name, erros};
  }

  async function uploadDocumentosAssistido(files, assistidoId, data){
    if(!Array.isArray(files) || !files.length){
      return {ok:false, error:'Nenhum arquivo recebido para documentos pessoais.'};
    }
    const id = String(assistidoId || getAssistidoIdFromUrl() || data?.assistido_id || data?.id || '').replace(/\D/g, '');
    if(!id){
      return {
        ok:false,
        error:'Nao encontrei assistido_id. Salve o cadastro primeiro ou abra /assistido/editar/ID/0/#documentos.',
        href: location.href
      };
    }

    const inputResp = await injetarArquivosEmInputVisivel(files);
    if(inputResp.ok) return {...inputResp, assistido_id:id};

    const tipos = await getTiposDocumentoPessoal();
    const enviados = [];
    const erros = [];
    for(const item of files){
      const resp = await uploadDocumentoAssistidoDireto(id, item, tipos);
      if(resp.ok) enviados.push({nome:item.name, endpoint:resp.endpoint, status:resp.status});
      else erros.push(resp);
    }
    return {
      ok: enviados.length > 0 && erros.length === 0,
      parcial: enviados.length > 0 && erros.length > 0,
      modo:'post_direto_assistido',
      assistido_id:id,
      inputFallback: inputResp,
      enviados,
      erros,
      diagnosticoDocumentos: enviados.length ? null : diagnosticarDocumentosAssistido()
    };
  }

  async function tentarAbrirAtendimentoInicial(){
    if(!location.pathname.includes('/atendimento/listar/')) return {ok:false, error:'A tela atual nao e a listagem de atendimentos.'};
    const candidates = Array.from(document.querySelectorAll('a, button, input[type="button"], input[type="submit"]'))
      .filter(isVisible);
    const btn = candidates.find(el => {
      const t = textOf(el);
      return t.includes('atendimento inicial agora') || t.includes('atendimento inicial');
    });
    if(!btn) return {ok:false, error:'Nao encontrei o botao Atendimento Inicial Agora na tela atual.'};
    setTimeout(() => btn.click(), 80);
    return {
      ok:true,
      abrindo:true,
      href:location.href,
      mensagem:'Cliquei em Atendimento Inicial Agora. Aguarde a nova tela carregar e clique em Injetar anexos novamente.'
    };
  }

  function isQualificacaoPage(){
    const bodyText = norm(document.body?.innerText || '');
    return bodyText.includes('buscar qualificacao') || bodyText.includes('qualificacao');
  }

  function visibleControls(selector){
    return Array.from(document.querySelectorAll(selector)).filter(isVisible);
  }

  function clickByText(selector, patterns){
    const wanted = patterns.map(norm);
    const el = visibleControls(selector).find(item => {
      const t = textOf(item);
      return wanted.some(p => t.includes(p));
    });
    if(el){
      el.click();
      return el;
    }
    return null;
  }

  async function buscarAlimentosQualificacao(){
    const selects = visibleControls('select');
    const area = selects.find(sel => Array.from(sel.options || []).some(opt => norm(opt.textContent).includes('familia') && norm(opt.textContent).includes('sucess')));
    if(area) selectByTextOrValue(area, 'Familia e Sucessoes');

    const textInputs = visibleControls('input[type="text"], input[type="search"], input:not([type])');
    const search = textInputs[textInputs.length - 1];
    if(search) setNativeValue(search, 'ALIMENTOS');

    const button = visibleControls('button, input[type="button"], input[type="submit"], a').find(el => {
      const t = textOf(el);
      return t.includes('buscar') || t.includes('pesquisar') || t === '' || el.querySelector('.fa-search, .glyphicon-search, [class*="search"]');
    });
    if(button) button.click();
    await wait(1000);
  }

  async function clicarAlimentosFamilia(){
    for(let i = 0; i < 20; i++){
      const rows = visibleControls('tr');
      const row = rows.find(tr => {
        const t = norm(tr.innerText || '');
        return t.includes('alimentos') && t.includes('familia') && t.includes('sucess');
      });
      if(row){
        const link = Array.from(row.querySelectorAll('a, button')).find(el => textOf(el) === 'alimentos') ||
          Array.from(row.querySelectorAll('a, button')).find(el => textOf(el).includes('alimentos')) ||
          row.querySelector('a, button');
        if(link){
          link.click();
          return {ok:true, etapa:'qualificacao_selecionada'};
        }
      }
      await wait(500);
    }
    return {ok:false, error:'Nao encontrei a linha ALIMENTOS da area FAMILIA E SUCESSOES.'};
  }

  async function confirmarModalQualificar(){
    for(let i = 0; i < 20; i++){
      const clicked = clickByText('.modal button, .modal a, button, a', ['qualificar']);
      if(clicked) return {ok:true, etapa:'modal_qualificar'};
      await wait(500);
    }
    return {ok:false, error:'Nao encontrei o botao Qualificar no modal.'};
  }

  function hasProcesso(data){
    return !!onlyDigits(data?.processo?.numero || data?.numero_processo || data?.cnj);
  }

  function preencherProcessoSeHouver(data){
    const processo = data?.processo || {};
    const numero = processo.numero || data?.numero_processo || data?.cnj || '';
    if(!numero) return {preencheu:false};
    setAnyField('input[name*="processo"], input[id*="processo"], input[name*="numero"], input[id*="numero"]', numero);
    setAnyField('input[name*="comarca"], input[id*="comarca"]', processo.comarca || '');
    setAnyField('input[name*="vara"], input[id*="vara"]', processo.vara || '');
    setAnyField('input[name*="classe"], input[id*="classe"]', processo.classe || '');
    return {preencheu:true, numero};
  }

  async function avancarQualificacao(data){
    await wait(1000);
    const processo = preencherProcessoSeHouver(data);
    const btn = clickByText('button, a, input[type="button"], input[type="submit"]', ['avancar', 'avançar', 'proximo', 'próximo']);
    if(btn){
      return {
        ok:true,
        abrindo:true,
        processo,
        mensagem:'Cliquei em Avancar na qualificacao. Aguarde a proxima tela carregar e clique em Injetar anexos novamente.'
      };
    }
    return {
      ok:true,
      precisaInteracao:true,
      processo,
      mensagem: processo.preencheu
        ? 'Preenchi dados do processo, mas nao encontrei botao Avancar.'
        : 'Nao havia processo no JSON e nao encontrei botao Avancar.'
    };
  }

  async function automatizarQualificacaoAlimentos(data){
    if(!isQualificacaoPage()) return {ok:false, error:'A tela atual nao parece ser a tela de Qualificacao.'};
    await buscarAlimentosQualificacao();
    const escolha = await clicarAlimentosFamilia();
    if(!escolha.ok) return escolha;
    const modal = await confirmarModalQualificar();
    if(!modal.ok) return modal;
    const avancar = await avancarQualificacao(data);
    return {
      ok:true,
      abrindo: !!avancar.abrindo,
      qualificacao: 'ALIMENTOS - FAMILIA E SUCESSOES',
      escolha,
      modal,
      avancar,
      mensagem: avancar.mensagem || 'Qualificacao selecionada.'
    };
  }

  async function getTiposDocumentoAtendimento(){
    const r = await fetch('/api/v1/tipos-documento.json?ativo=true&exibir_em_documento_atendimento=true', {
      credentials: 'same-origin',
      headers: {'Accept':'application/json, text/plain, */*'}
    });
    if(!r.ok) throw new Error('Nao consegui listar tipos de documento: HTTP '+r.status);
    const data = await r.json();
    return data.results || [];
  }

  function tipoDocumentoParaArquivo(file, tipos){
    const n = norm((file.kind || '') + ' ' + (file.path || '') + ' ' + (file.name || ''));
    const prefer = [];
    if(n.includes('rg') || n.includes('identidade')) prefer.push('carteira de identidade', 'rg');
    if(n.includes('cpf')) prefer.push('cadastro de pessoa fisica', 'cpf');
    if(n.includes('resid') || n.includes('endere')) prefer.push('comprovante de endereco');
    if(n.includes('renda')) prefer.push('comprovante de renda');
    if(n.includes('casamento')) prefer.push('certidao de casamento');
    if(n.includes('uniao')) prefer.push('certidao de uniao estavel');
    if(n.includes('certidao') || n.includes('nascimento')) prefer.push('certidao de nascimento');
    prefer.push('documentos', 'outros');

    for(const wanted of prefer){
      const found = tipos.find(t => {
        const nome = norm(t.nome);
        return nome === wanted || nome.includes(wanted) || wanted.includes(nome);
      });
      if(found) return found.id;
    }
    return 29;
  }

  async function uploadDocumentosAtendimento(files, data){
    if(!Array.isArray(files) || !files.length){
      return {ok:false, error:'Nenhum arquivo recebido para upload.'};
    }
    let numero = getAtendimentoNumero();
    if(!numero){
      if(isQualificacaoPage()){
        return await automatizarQualificacaoAlimentos(data || {});
      }
      const abertura = await tentarAbrirAtendimentoInicial();
      if(abertura.ok && abertura.numero) numero = abertura.numero;
      else if(abertura.ok && abertura.abrindo) return abertura;
      else {
      const saved = location.pathname.includes('/assistido/editar/')
        ? 'O assistido pode estar salvo, mas ainda falta criar ou abrir o atendimento do caso.'
        : 'A tela atual nao contem um numero de atendimento.';
      return {
        ok:false,
        error: saved + ' Para anexar documentos do caso, abra uma URL no formato /atendimento/NUMERO/ antes de clicar em injetar documentos. URL atual: '+location.href,
        precisaAtendimento: true,
        tentativaAbrirAtendimento: abertura,
        href: location.href
      };
      }
    }
    const tipos = await getTiposDocumentoAtendimento();
    const csrf = getCsrf();
    const enviados = [];
    const erros = [];
    for(const item of files){
      try{
        const file = dataUrlToFile(item);
        const fd = new FormData();
        fd.append('nome', (item.name || file.name || 'documento').replace(/\.[^.]+$/, ''));
        fd.append('documento', String(tipoDocumentoParaArquivo(item, tipos)));
        fd.append('arquivo', file, file.name);
        fd.append('$$hashKey', item.hashKey || 'EXT');
        const r = await fetch(`/atendimento/${numero}/documento/salvar/false`, {
          method: 'POST',
          credentials: 'same-origin',
          headers: csrf ? {'X-CSRFToken': csrf} : {},
          body: fd
        });
        const text = await r.text();
        if(!r.ok) throw new Error('HTTP '+r.status+' '+text.slice(0, 180));
        enviados.push({nome:item.name, status:r.status});
      }catch(e){
        erros.push({nome:item.name, erro:e.message || String(e)});
      }
    }
    return {
      ok: enviados.length > 0 && erros.length === 0,
      parcial: enviados.length > 0 && erros.length > 0,
      atendimento: numero,
      enviados,
      erros
    };
  }

  function validar(){
    let invalid = [];
    try{
      if(!window.angular) return validarDom();
      const scope=getScope();
      if(scope.AssistidoForm){
        Object.keys(scope.AssistidoForm).forEach(k=>{
          const c=scope.AssistidoForm[k];
          if(c && c.$invalid) invalid.push(k);
        });
      }
      const p=scope.pessoa || {};
      const faltas=[];
      if(!p.cpf) faltas.push('cpf');
      if(!p.nome) faltas.push('nome');
      if(!p.data_nascimento) faltas.push('data_nascimento');
      if(!p.filiacao || !p.filiacao[0] || !p.filiacao[0].nome) faltas.push('filiacao');
      if(!p.telefones || !p.telefones[0] || !(p.telefones[0].telefone || p.telefones[0].numero)) faltas.push('telefone');
      return {ok: invalid.length===0 && faltas.length===0, angularInvalid: invalid, faltas, pessoaResumo:{
        cpf:p.cpf,nome:p.nome,data_nascimento:p.data_nascimento,
        filiacao:p.filiacao&&p.filiacao[0]&&p.filiacao[0].nome,
        telefone:p.telefones&&p.telefones[0]&&(p.telefones[0].telefone || ((p.telefones[0].ddd||'')+(p.telefones[0].numero||''))),
        email:p.email, estado_civil:p.estado_civil, nacionalidade:p.nacionalidade
      }};
    }catch(e){ return {ok:false,error:e.message}; }
  }

  chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
    (async()=>{
      try{
        if(msg.type==='SOLAR_PING') sendResponse({ok:true, href: location.href, v:'0.9.0'});
        else if(msg.type==='SOLAR_CONSULTAR_CPF') sendResponse(await consultarCpf(msg.cpf));
        else if(msg.type==='SOLAR_PREENCHER_BASICO') sendResponse(await preencherBasico(msg.data));
        else if(msg.type==='SOLAR_SALVAR_ASSISTIDO') sendResponse(await salvarAssistido());
        else if(msg.type==='SOLAR_INJETAR_ARQUIVOS_ATUAL') sendResponse(await injetarArquivosAtual(msg.files));
        else if(msg.type==='SOLAR_UPLOAD_DOCUMENTOS_ASSISTIDO') sendResponse(await uploadDocumentosAssistido(msg.files, msg.assistidoId, msg.data));
        else if(msg.type==='SOLAR_UPLOAD_DOCUMENTOS_ATENDIMENTO') sendResponse(await uploadDocumentosAtendimento(msg.files, msg.data));
        else if(msg.type==='SOLAR_VALIDAR') sendResponse(validar());
        else sendResponse({ok:false,error:'Mensagem desconhecida no content script.'});
      }catch(e){ sendResponse({ok:false,error:e.message || String(e)}); }
    })();
    return true;
  });
})();
