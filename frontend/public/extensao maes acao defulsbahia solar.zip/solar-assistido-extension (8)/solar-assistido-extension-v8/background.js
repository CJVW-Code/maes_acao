const SOLAR_ORIGIN = 'https://solar.defensoria.ba.def.br/';

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function extApi() { return globalThis.browser || globalThis.chrome; }

if (extApi().runtime && extApi().runtime.onInstalled && extApi().sidePanel) {
  extApi().runtime.onInstalled.addListener(() => {
    extApi().sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  });
}

if (extApi().action && extApi().action.onClicked && extApi().sidePanel) {
  extApi().action.onClicked.addListener(async (tab) => {
    try {
      if (tab && tab.windowId) await extApi().sidePanel.open({ windowId: tab.windowId });
    } catch (_) {}
  });
}

async function getActiveSolarTab() {
  const [tab] = await extApi().tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) throw new Error('Não encontrei a aba ativa.');
  if (!tab.url || !tab.url.startsWith(SOLAR_ORIGIN)) {
    throw new Error('Abra qualquer página interna do SOLAR já logada antes de executar.');
  }
  return tab;
}

async function ping(tabId) {
  try {
    const resp = await extApi().tabs.sendMessage(tabId, { type: 'SOLAR_PING' });
    return !!(resp && resp.ok);
  } catch (_) {
    return false;
  }
}

async function ensureContentScript(tabId) {
  if (await ping(tabId)) return true;
  await extApi().scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  for (let i = 0; i < 12; i++) {
    await sleep(250);
    if (await ping(tabId)) return true;
  }
  throw new Error('Não consegui conectar o script da extensão à página do SOLAR. Recarregue a página e tente novamente.');
}

async function sendToPage(tabId, message) {
  await ensureContentScript(tabId);
  return await Promise.race([
    extApi().tabs.sendMessage(tabId, message),
    new Promise((resolve) => setTimeout(() => resolve({
      ok: false,
      error: `Tempo esgotado aguardando resposta da pagina (${message.type}).`
    }), 60000))
  ]);
}

function buildSolarUrl(path, query = {}) {
  const url = new URL(path || '/', SOLAR_ORIGIN);
  for (const [key, value] of Object.entries(query || {})) {
    if (value !== undefined && value !== null && String(value) !== '') {
      url.searchParams.set(key, String(value));
    }
  }
  return url.toString();
}

async function waitForTabComplete(tabId, timeoutMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const tab = await extApi().tabs.get(tabId);
    if (tab && tab.status === 'complete') return tab;
    await sleep(500);
  }
  throw new Error('A pagina do SOLAR nao terminou de carregar dentro do tempo esperado.');
}

async function consultarCpfEAbrir(tab, cpf) {
  const consulta = await sendToPage(tab.id, { type: 'SOLAR_CONSULTAR_CPF', cpf });
  if (!consulta || !consulta.ok) {
    return { ok: false, etapa: 'consulta', error: consulta?.error || 'Falha ao consultar CPF.', consulta };
  }
  if (consulta.existe) return { ok: true, existe: true, consulta };

  const cpfLimpo = String(cpf || '').replace(/\D/g, '');
  const url = `${SOLAR_ORIGIN}assistido/editar/0/0/?next=/atendimento/listar/&nome=&cpf=${cpfLimpo}#basico`;
  await extApi().tabs.update(tab.id, { url });
  return { ok: true, existe: false, abriuCadastro: true, url };
}

async function automatizarAssistido(data, options = {}) {
  const tab = await getActiveSolarTab();
  const consulta = await consultarCpfEAbrir(tab, data.cpf);
  if (!consulta.ok || consulta.existe) return consulta;

  await waitForTabComplete(tab.id);
  await ensureContentScript(tab.id);
  const preenchimento = await sendToPage(tab.id, { type: 'SOLAR_PREENCHER_BASICO', data });
  const resultado = { ok: !!(preenchimento && preenchimento.ok), consulta, preenchimento };

  if (options.salvar && preenchimento && preenchimento.ok) {
    resultado.salvamento = await sendToPage(tab.id, { type: 'SOLAR_SALVAR_ASSISTIDO' });
    resultado.ok = !!(resultado.salvamento && resultado.salvamento.ok);
  }

  return resultado;
}

extApi().runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === 'BG_CONSULTAR_CPF_E_ABRIR') {
        const tab = await getActiveSolarTab();
        sendResponse(await consultarCpfEAbrir(tab, msg.cpf));
        return;
      }

      if (msg.type === 'BG_PREENCHER_BASICO' || msg.type === 'BG_VALIDAR_PAGINA') {
        const tab = await getActiveSolarTab();
        if (msg.type === 'BG_PREENCHER_BASICO') await waitForTabComplete(tab.id, 45000);
        const resp = await sendToPage(tab.id, msg.type === 'BG_PREENCHER_BASICO'
          ? { type: 'SOLAR_PREENCHER_BASICO', data: msg.data }
          : { type: 'SOLAR_VALIDAR' });
        sendResponse(resp || { ok: false, error: 'Sem resposta da página.' });
        return;
      }

      if (msg.type === 'BG_SALVAR_ASSISTIDO') {
        const tab = await getActiveSolarTab();
        const resp = await sendToPage(tab.id, { type: 'SOLAR_SALVAR_ASSISTIDO' });
        sendResponse(resp || { ok: false, error: 'Sem resposta da pagina ao salvar.' });
        return;
      }

      if (msg.type === 'BG_AUTOMATIZAR_ASSISTIDO') {
        sendResponse(await automatizarAssistido(msg.data, msg.options || {}));
        return;
      }

      if (msg.type === 'BG_INJETAR_ARQUIVOS_ATUAL') {
        const tab = await getActiveSolarTab();
        const resp = await sendToPage(tab.id, { type: 'SOLAR_UPLOAD_DOCUMENTOS_ATENDIMENTO', files: msg.files || [], data: msg.data || null });
        sendResponse(resp || { ok: false, error: 'Sem resposta da pagina.' });
        return;
      }

      if (msg.type === 'BG_UPLOAD_DOCUMENTOS_ASSISTIDO') {
        const tab = await getActiveSolarTab();
        const resp = await sendToPage(tab.id, {
          type: 'SOLAR_UPLOAD_DOCUMENTOS_ASSISTIDO',
          files: msg.files || [],
          assistidoId: msg.assistidoId || '',
          data: msg.data || null
        });
        sendResponse(resp || { ok: false, error: 'Sem resposta da pagina.' });
        return;
      }

      if (msg.type === 'BG_ABRIR_URL_SOLAR') {
        const tab = await getActiveSolarTab();
        let url = buildSolarUrl(msg.path, msg.query || {});
        if (msg.hash) url += `#${String(msg.hash).replace(/^#/, '')}`;
        await extApi().tabs.update(tab.id, { url });
        sendResponse({ ok: true, url });
        return;
      }

      if (msg.type === 'BG_INJETAR') {
        const tab = await getActiveSolarTab();
        await ensureContentScript(tab.id);
        sendResponse({ ok: true, tabId: tab.id });
        return;
      }

      sendResponse({ ok: false, error: 'Mensagem desconhecida no background.' });
    } catch (e) {
      sendResponse({ ok: false, error: e.message || String(e) });
    }
  })();
  return true;
});
