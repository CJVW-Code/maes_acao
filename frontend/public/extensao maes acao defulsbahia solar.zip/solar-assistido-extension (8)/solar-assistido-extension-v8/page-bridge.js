(function(){
  if(window.__SOLAR_ASSISTIDO_PAGE_BRIDGE__) return;
  window.__SOLAR_ASSISTIDO_PAGE_BRIDGE__ = true;

  function onlyDigits(s){ return String(s || '').replace(/\D/g, ''); }
  function norm(s){ return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); }
  function firstValue(){
    for(var i = 0; i < arguments.length; i++){
      var value = arguments[i];
      if(value !== undefined && value !== null && String(value).trim() !== '') return value;
    }
    return '';
  }

  function hasAddress(data){
    return !!(data && (data.cep || data.logradouro || data.bairro || data.municipio || data.municipio_nome || data.estado || data.estado_nome));
  }

  function estadoId(value){
    var raw = firstValue(value, '').trim();
    var t = norm(raw);
    var byUf = {
      ac: 12, al: 27, ap: 16, am: 13, ba: 29, ce: 23, df: 53, es: 32, go: 52,
      ma: 21, mt: 51, ms: 50, mg: 31, pa: 15, pb: 25, pr: 41, pe: 26, pi: 22,
      rj: 33, rn: 24, rs: 43, ro: 11, rr: 14, sc: 42, sp: 35, se: 28, to: 17
    };
    if(/^\d+$/.test(raw)) return Number(raw);
    if(byUf[t]) return byUf[t];
    if(t.indexOf('bahia') >= 0) return 29;
    return raw || 29;
  }

  function addressType(value){
    var t = norm(value);
    if(t.indexOf('comerc') >= 0) return 20;
    if(t.indexOf('correspond') >= 0) return 30;
    if(t.indexOf('altern') >= 0) return 40;
    return Number(value) || 10;
  }

  function addressArea(value){
    var t = norm(value);
    if(t.indexOf('rural') >= 0) return 1;
    return Number(value) || 0;
  }

  async function getCepData(cep){
    var digits = onlyDigits(cep);
    if(digits.length !== 8) return null;
    try{
      var r = await fetch('/endereco/get_by_cep/' + digits + '/', {
        credentials: 'same-origin',
        headers: {'Accept': 'application/json, text/plain, */*'}
      });
      if(!r.ok) return null;
      return await r.json();
    }catch(e){
      return null;
    }
  }

  async function resolveMunicipioId(data, estado){
    var existing = firstValue(data.municipio, data.municipio_id, '');
    if(/^\d+$/.test(String(existing))) return Number(existing);
    var nome = norm(firstValue(data.municipio_nome, data.cidade_nome, data.municipio, data.cidade, ''));
    if(!nome) return existing || '';
    try{
      var r = await fetch('/estado/' + estado + '/municipios/', {
        credentials: 'same-origin',
        headers: {'Accept': 'application/json, text/plain, */*'}
      });
      if(!r.ok) return existing || '';
      var municipios = await r.json();
      for(var i = 0; i < municipios.length; i++){
        var item = municipios[i];
        var itemNome = norm(item.nome || '');
        if(itemNome === nome || itemNome.indexOf(nome) >= 0 || nome.indexOf(itemNome) >= 0) return item.id;
      }
    }catch(e){}
    return existing || '';
  }

  async function resolveMunicipio(data, estado, municipioValue){
    var id = firstValue(municipioValue, data.municipio, data.municipio_id, '');
    var nome = firstValue(data.municipio_nome, data.cidade_nome, data.cidade, '');
    if(nome && /^\d+$/.test(String(id || ''))) return {id: Number(id), nome: nome};

    var nomeBusca = norm(firstValue(nome, /^\d+$/.test(String(id || '')) ? '' : id, ''));
    try{
      var r = await fetch('/estado/' + estado + '/municipios/', {
        credentials: 'same-origin',
        headers: {'Accept': 'application/json, text/plain, */*'}
      });
      if(r.ok){
        var municipios = await r.json();
        for(var i = 0; i < municipios.length; i++){
          var item = municipios[i];
          if(/^\d+$/.test(String(id || '')) && Number(item.id) === Number(id)){
            return {id: item.id, nome: item.nome};
          }
          var itemNome = norm(item.nome || '');
          if(nomeBusca && (itemNome === nomeBusca || itemNome.indexOf(nomeBusca) >= 0 || nomeBusca.indexOf(itemNome) >= 0)){
            return {id: item.id, nome: item.nome};
          }
        }
      }
    }catch(e){}

    if(/^\d+$/.test(String(id || ''))) return {id: Number(id), nome: nome || ''};
    return {id: id || '', nome: nome || id || ''};
  }

  async function buildAddress(data){
    if(!hasAddress(data)) return null;
    var cepInfo = await getCepData(data.cep);
    var estado = estadoId(firstValue(data.estado, data.estado_id, data.uf, cepInfo && cepInfo.estado_id, '29'));
    var municipio = firstValue(data.municipio, data.municipio_id, cepInfo && (cepInfo.municipio_id || cepInfo.municipio), '');
    if(!/^\d+$/.test(String(municipio || ''))) municipio = await resolveMunicipioId(data, estado);
    var municipioObj = await resolveMunicipio(data, estado, municipio);
    var tipo = addressType(firstValue(data.tipo_endereco, data.endereco_tipo, 10));
    var tipoArea = addressArea(data.tipo_area);

    return {
      id: null,
      logradouro: firstValue(data.logradouro, cepInfo && cepInfo.logradouro, ''),
      numero: firstValue(data.numero, data.endereco_numero, ''),
      complemento: firstValue(data.complemento, cepInfo && cepInfo.complemento, ''),
      cep: onlyDigits(firstValue(data.cep, cepInfo && cepInfo.cep, '')),
      bairro: firstValue(data.bairro, cepInfo && cepInfo.bairro, ''),
      municipio_id: municipioObj.id,
      municipio: municipioObj.nome,
      tipo_area: {
        id: tipoArea,
        nome: tipoArea === 1 ? 'Rural' : 'Urbana'
      },
      principal: true,
      tipo: {
        id: tipo,
        nome: ({10:'Residencial', 20:'Comercial', 30:'Correspondencia', 40:'Alternativo'})[tipo] || 'Residencial'
      },
      estado_id: String(estado || 29),
      estado: ({12:'AC',27:'AL',16:'AP',13:'AM',29:'BA',23:'CE',53:'DF',32:'ES',52:'GO',21:'MA',51:'MT',50:'MS',31:'MG',15:'PA',25:'PB',41:'PR',26:'PE',22:'PI',33:'RJ',24:'RN',43:'RS',11:'RO',14:'RR',42:'SC',35:'SP',28:'SE',17:'TO'})[Number(estado)] || String(estado || 'BA'),
      is_cep_correto: true
    };
  }

  function getCsrf(){
    return document.querySelector('input[name=csrfmiddlewaretoken]')?.value ||
      document.querySelector('#csrf_token')?.value ||
      (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  }

  function findPessoaScopeFrom(el){
    if(!el || !window.angular) return null;
    var wrapped = window.angular.element(el);
    var scope = (wrapped.scope && wrapped.scope()) || (wrapped.isolateScope && wrapped.isolateScope());
    while(scope){
      if(scope.pessoa) return scope;
      scope = scope.$parent;
    }
    return null;
  }

  function getScope(){
    if(!window.angular) throw new Error('Angular nao esta disponivel no contexto da pagina.');
    var candidates = [
      '[ng-controller="CadastrarPessoaModel"]',
      '[data-ng-controller="CadastrarPessoaModel"]',
      '#AssistidoForm',
      '#ContentSide',
      '[ng-model^="pessoa."]',
      '[data-ng-model^="pessoa."]',
      '#id_cpf',
      'body'
    ];
    for(var i = 0; i < candidates.length; i++){
      var scope = findPessoaScopeFrom(document.querySelector(candidates[i]));
      if(scope) return scope;
    }
    throw new Error('Escopo Angular do cadastro nao encontrado.');
  }

  function estadoCivilValue(texto){
    var t = norm(texto);
    var select = document.querySelector('#id_estado_civil');
    if(select && t){
      for(var i = 0; i < select.options.length; i++){
        var opt = select.options[i];
        var optionText = norm(opt.textContent || '');
        if(optionText === t || optionText.indexOf(t) >= 0 || t.indexOf(optionText) >= 0) return opt.value;
      }
    }
    if(t.indexOf('casad') >= 0) return '1';
    if(t.indexOf('uniao') >= 0 || t.indexOf('conviv') >= 0) return '6';
    if(t.indexOf('divorci') >= 0) return '3';
    if(t.indexOf('separad') >= 0) return '2';
    if(t.indexOf('viuv') >= 0) return '4';
    if(t.indexOf('solteir') >= 0) return '0';
    return '';
  }

  function isCasadoOuUniao(data){
    var t = norm(data.estado_civil_texto);
    return t.indexOf('casad') >= 0 || t.indexOf('uniao') >= 0 || t.indexOf('conviv') >= 0;
  }

  async function fillAngular(data){
    var scope = getScope();
    var endereco = await buildAddress(data);
    scope.$apply(function(){
      var p = scope.pessoa;
      p.cpf = onlyDigits(data.cpf);
      p.nome = data.nome || '';
      p.email = data.email || '';
      p.data_nascimento = data.data_nascimento || '';

      if(!Array.isArray(p.filiacao) || !p.filiacao.length) p.filiacao = [{id:null,nome:null,tipo:0}];
      p.filiacao[0].nome = data.filiacao || 'DESCONHECIDO';
      p.filiacao[0].tipo = 0;

      if(!Array.isArray(p.telefones) || !p.telefones.length) p.telefones = [{id:null,ddd:null,numero:null,telefone:null,nome:null,tipo:0}];
      p.telefones[0].tipo = 0;
      p.telefones[0].telefone = data.telefone_formatado || data.telefone || '';
      p.telefones[0].ddd = onlyDigits(data.telefone).slice(0,2);
      p.telefones[0].numero = onlyDigits(data.telefone).slice(2);
      p.telefones[0].nome = data.nome || '';

      var estadoCivil = estadoCivilValue(data.estado_civil_texto);
      if(estadoCivil !== '') p.estado_civil = estadoCivil;
      if(norm(data.nacionalidade_texto).indexOf('brasileir') >= 0) p.nacionalidade = '0';
      if(norm(data.tipo_trabalho_texto).indexOf('benef') >= 0) p.tipo_trabalho = '5';
      p.profissao = firstValue(data.profissao, p.profissao);
      p.rg_numero = firstValue(data.rg_numero, p.rg_numero);
      p.rg_orgao = firstValue(data.rg_orgao, p.rg_orgao);
      p.rg_data_expedicao = firstValue(data.rg_data_expedicao, p.rg_data_expedicao);
      p.raca = firstValue(data.raca, p.raca);
      p.escolaridade = firstValue(data.escolaridade, p.escolaridade);
      p.numero_membros = Number(firstValue(data.renda_numero_membros, p.numero_membros, 1)) || 1;
      p.numero_membros_economicamente_ativos = Number(firstValue(data.renda_numero_membros_economicamente_ativos, p.numero_membros_economicamente_ativos, 0)) || 0;
      p.ganho_mensal = firstValue(data.renda_individual, p.ganho_mensal, '0.00');
      p.ganho_mensal_membros = firstValue(data.renda_familiar, p.ganho_mensal_membros, '0.00');
      p.tem_plano_saude = firstValue(data.tem_plano_saude, p.tem_plano_saude, 0);
      p.isento_ir = firstValue(data.isento_ir, p.isento_ir, 1);
      p.previdencia = firstValue(data.previdencia, p.previdencia, 0);
      if(!Array.isArray(p.patrimonios)) p.patrimonios = [];

      if(isCasadoOuUniao(data)){
        if(!Array.isArray(p.membros) || !p.membros.length) p.membros = [{id:null,nome:null,parentesco:0,renda:'0.00'}];
        p.membros[0].nome = data.nome_conjuge || p.membros[0].nome || 'desconhecido';
        p.membros[0].parentesco = p.membros[0].parentesco == null ? 0 : p.membros[0].parentesco;
        p.membros[0].renda = p.membros[0].renda || '0.00';
      } else {
        p.membros = [];
      }

      if(endereco){
        p.logradouro = firstValue(endereco.logradouro, p.logradouro);
        p.numero = firstValue(endereco.numero, p.numero);
        p.complemento = firstValue(endereco.complemento, p.complemento);
        p.cep = firstValue(endereco.cep, p.cep);
        p.bairro = firstValue(endereco.bairro, p.bairro);
        p.municipio = firstValue(endereco.municipio_id, p.municipio);
        p.estado = firstValue(endereco.estado_id, p.estado);
        p.tipo_area = endereco.tipo_area.id;
        p.principal = true;
        p.tipo = endereco.tipo.id;
        scope.assistido_enderecos = [endereco];
      }
    });
    return {
      ok:true,
      hasAngular:true,
      pessoa_id: scope.pessoa && scope.pessoa.id,
      enderecos: Array.isArray(scope.assistido_enderecos) ? scope.assistido_enderecos.length : 0,
      endereco: endereco
    };
  }

  async function saveAngular(){
    var scope = getScope();
    if(typeof scope.processar_telefone === 'function') scope.processar_telefone(scope.pessoa.telefones || []);
    scope.pessoa.tipo_cadastro = 20;
    if(!Array.isArray(scope.pessoa.patrimonios)) scope.pessoa.patrimonios = [];
    if(!Array.isArray(scope.assistido_enderecos)) scope.assistido_enderecos = [];

    var action = document.querySelector('#AssistidoForm')?.getAttribute('action') || '/assistido/salvar/';
    var payload = {
      pessoa: scope.pessoa,
      enderecos: scope.assistido_enderecos
    };
    var r = await fetch(action, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8',
        'Accept': 'application/json, text/plain, */*',
        'X-CSRFToken': getCsrf(),
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: JSON.stringify(payload)
    });
    var text = await r.text();
    var data;
    try { data = JSON.parse(text); } catch(_) { data = {raw:text}; }
    var success = !!(r.ok && data && (data.success || data.id || (data.pessoa && data.pessoa.id)));
    var enderecoError = null;
    if(!success && payload.enderecos.length){
      enderecoError = {
        status: r.status,
        data: data,
        mensagem: 'Falha ao salvar com endereco; tentando salvar o assistido sem endereco para nao bloquear o fluxo.'
      };
      payload = {
        pessoa: scope.pessoa,
        enderecos: []
      };
      r = await fetch(action, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json;charset=UTF-8',
          'Accept': 'application/json, text/plain, */*',
          'X-CSRFToken': getCsrf(),
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(payload)
      });
      text = await r.text();
      try { data = JSON.parse(text); } catch(_) { data = {raw:text}; }
      success = !!(r.ok && data && (data.success || data.id || (data.pessoa && data.pessoa.id)));
    }
    return {
      ok: success,
      status: r.status,
      data: data,
      assistido_id: String(data.id || (data.pessoa && data.pessoa.id) || (scope.pessoa && scope.pessoa.id) || ''),
      endereco_error: enderecoError,
      payloadResumo: {
        cpf: scope.pessoa && scope.pessoa.cpf,
        nome: scope.pessoa && scope.pessoa.nome,
        filiacao: scope.pessoa && scope.pessoa.filiacao && scope.pessoa.filiacao[0] && scope.pessoa.filiacao[0].nome,
        estado_civil: scope.pessoa && scope.pessoa.estado_civil,
        tipo_trabalho: scope.pessoa && scope.pessoa.tipo_trabalho,
        enderecos: payload.enderecos.length
      }
    };
  }

  window.addEventListener('message', async function(event){
    var msg = event.data || {};
    if(event.source !== window || msg.source !== 'solar-assistido-content' || !msg.id) return;
    try{
      var result;
      if(msg.action === 'fillAngular') result = await fillAngular(msg.payload || {});
      else if(msg.action === 'saveAngular') result = await saveAngular();
      else result = {ok:false, error:'Acao desconhecida no page bridge.'};
      window.postMessage({source:'solar-assistido-page', id:msg.id, result:result}, '*');
    }catch(e){
      window.postMessage({source:'solar-assistido-page', id:msg.id, result:{ok:false, error:e && e.message ? e.message : String(e)}}, '*');
    }
  });
})();
