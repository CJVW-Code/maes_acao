const api = globalThis.browser || globalThis.chrome;
const $ = (id) => document.getElementById(id);

let currentProject = null;
let selectedFiles = [];
let lastAssistidoId = '';
const MAX_LISTED_FILES = 500;
const MAX_LOG_FILES = 20;
const MAX_UPLOAD_FILES = 80;
const MAX_UPLOAD_TOTAL_BYTES = 120 * 1024 * 1024;

function onlyDigits(s){ return String(s || '').replace(/\D/g, ''); }
function cleanText(s){ return String(s || '').trim().replace(/\s+/g, ' '); }
function removeAccents(s){ return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
function upper(s){ return removeAccents(cleanText(s)).toUpperCase(); }
function extractMae(s){
  const text = cleanText(s);
  const m = text.match(/m[aã]e\s*:\s*([^,;]+)/i);
  return cleanText(m ? m[1] : text);
}
function cpfMask(d){ d = onlyDigits(d); return d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : d; }
function phoneMask(d){
  d = onlyDigits(d);
  if(d.length === 11) return d.replace(/(\d{2})(\d{5})(\d{4})/, '($1)$2-$3');
  if(d.length === 10) return d.replace(/(\d{2})(\d{4})(\d{4})/, '($1)$2-$3');
  return d;
}

function log(x, cls = ''){
  $('out').className = cls;
  try {
    $('out').textContent = typeof x === 'string' ? x : JSON.stringify(x, null, 2);
  } catch(e) {
    $('out').textContent = String(x);
  }
}

function appendLog(line){
  $('out').textContent = `${$('out').textContent || ''}\n${line}`.trim();
}

function sleep(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }
function fieldValue(id){ return $(id)?.value || ''; }

function sendBg(message, timeoutMs = 60000){
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => {
      if(done) return;
      done = true;
      resolve({
        ok: false,
        error: `Tempo esgotado aguardando resposta da extensao (${message.type}).`,
        type: message.type
      });
    }, timeoutMs);

    try {
      api.runtime.sendMessage(message, (resp) => {
        if(done) return;
        done = true;
        clearTimeout(timer);
        const err = api.runtime.lastError;
        if(err) {
          resolve({
            ok: false,
            error: err.message || String(err),
            type: message.type
          });
          return;
        }
        resolve(resp || { ok: false, error: 'Sem resposta da extensao.', type: message.type });
      });
    } catch(e) {
      if(done) return;
      done = true;
      clearTimeout(timer);
      resolve({ ok:false, error:e.message || String(e), type: message.type });
    }
  });
}

window.addEventListener('error', (event) => {
  log('Erro inesperado no painel: ' + (event.error?.message || event.message || 'erro desconhecido'), 'bad');
});

window.addEventListener('unhandledrejection', (event) => {
  log('Erro inesperado no painel: ' + (event.reason?.message || event.reason || 'promessa rejeitada'), 'bad');
});

function extractJson(text){
  text = String(text || '').trim();
  try { return JSON.parse(text); } catch(e) {}
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if(start >= 0 && end > start) return JSON.parse(text.slice(start, end + 1));
  throw new Error('Nao encontrei um objeto JSON valido no texto.');
}

function getSolarPayload(obj){
  return obj && obj.solar && typeof obj.solar === 'object' ? obj.solar : obj;
}

function firstClean(){
  for(const value of arguments){
    const cleaned = cleanText(value);
    if(cleaned) return cleaned;
  }
  return '';
}

function findAddressObject(root, solar){
  const direct = [
    solar.endereco,
    solar.requerente_endereco,
    solar.endereco_requerente,
    solar.endereco_assistido,
    solar.assistido_endereco,
    root.endereco,
    root.requerente?.endereco,
    root.assistido?.endereco,
    root.pessoa?.endereco
  ].find(obj => obj && typeof obj === 'object' && !Array.isArray(obj));
  if(direct) return direct;

  const seen = new Set();
  const queue = [{value: root, depth: 0}];
  while(queue.length){
    const {value, depth} = queue.shift();
    if(!value || typeof value !== 'object' || seen.has(value) || depth > 4) continue;
    seen.add(value);

    if(!Array.isArray(value)){
      const keys = Object.keys(value).map(k => removeAccents(k).toLowerCase());
      const hasCep = keys.some(k => k === 'cep' || k.includes('cep'));
      const hasStreet = keys.some(k => ['logradouro', 'rua', 'endereco', 'address'].includes(k) || k.includes('logradouro'));
      const hasCity = keys.some(k => ['municipio', 'cidade', 'city'].includes(k) || k.includes('municipio'));
      if(hasCep && (hasStreet || hasCity || keys.includes('bairro'))) return value;
    }

    const children = Array.isArray(value) ? value : Object.values(value);
    for(const child of children){
      if(child && typeof child === 'object') queue.push({value: child, depth: depth + 1});
    }
  }
  return {};
}

function buildObservacoes(root, solar){
  const caso = root.caso || {};
  return [
    caso.id && `CASO ID: ${caso.id}`,
    caso.protocolo && `PROTOCOLO: ${caso.protocolo}`,
    caso.tipo_acao && `TIPO DE ACAO: ${caso.tipo_acao}`,
    caso.status && `STATUS: ${caso.status}`,
    solar.representante_ocupacao && `OCUPACAO REPRESENTANTE: ${solar.representante_ocupacao}`,
    solar.rg_executado && `RG/CPF INFORMADO: ${solar.rg_executado}`,
    solar.emissor_rg_executado && `EMISSOR RG: ${solar.emissor_rg_executado}`,
    solar.certidao_tipo && `CERTIDAO TIPO: ${solar.certidao_tipo}`,
    solar.certidao_numero && `CERTIDAO NUMERO: ${solar.certidao_numero}`
  ].filter(Boolean).join('\n');
}

function extractProcesso(root, solar){
  const processo = root.processo || root.processual || root.caso?.processo || solar.processo || {};
  return {
    numero: cleanText(
      processo.numero ||
      processo.numero_processo ||
      processo.cnj ||
      solar.processo_numero ||
      solar.numero_processo ||
      solar.cnj
    ),
    comarca: cleanText(processo.comarca || solar.processo_comarca || solar.comarca),
    vara: cleanText(processo.vara || solar.processo_vara || solar.vara),
    classe: cleanText(processo.classe || solar.processo_classe || solar.classe_processual)
  };
}

function normalize(root){
  const solar = getSolarPayload(root);
  const endereco = findAddressObject(root, solar);
  const nascimento = cleanText(
    fieldValue('nascimento') ||
    solar.data_nascimento_assistido ||
    solar.nascimento ||
    solar.data_nascimento ||
    solar.assistido_data_nascimento
  );
  const filiacao = cleanText(
    fieldValue('filiacao') ||
    solar.nome_mae_assistido ||
    solar.mae_assistido ||
    solar.assistido_nome_mae ||
    solar.nome_mae ||
    solar.mae ||
    solar.filiacao ||
    solar.nome_mae_representante ||
    solar.representante_nome
  );
  const filiacaoNormalizada = upper(extractMae(filiacao)) || 'DESCONHECIDO';
  const estadoCivil = cleanText(
    solar.assistido_estado_civil ||
    solar.estado_civil_assistido ||
    solar.estado_civil ||
    'solteiro(a)'
  );
  const nacionalidade = cleanText(solar.nacionalidade || solar.assistido_nacionalidade);
  const telefone = solar.requerente_telefone || solar.telefone || solar.assistido_telefone || solar.representante_telefone;
  const email = solar.requerente_email || solar.email_assistido || solar.email || solar.representante_email;
  const cpf = solar.cpf || solar.assistido_cpf;
  const nome = solar.NOME || solar.nome || solar.assistido_nome;
  const estadoCivilNorm = removeAccents(estadoCivil).toLowerCase();
  const precisaConjuge = estadoCivilNorm.includes('casad') || estadoCivilNorm.includes('uniao') || estadoCivilNorm.includes('conviv');
  const nomeConjuge = cleanText(solar.nome_conjuge || solar.conjuge_nome || solar.representante_conjuge || solar.assistido_conjuge);

  const normalized = {
    origem: root.caso ? 'atendimento.json' : 'json-legado',
    caso: root.caso || null,
    cpf: onlyDigits(cpf),
    cpf_formatado: cpfMask(cpf),
    nome: upper(nome),
    email: cleanText(email),
    telefone: onlyDigits(telefone),
    telefone_formatado: phoneMask(telefone),
    estado_civil_texto: estadoCivil,
    nome_conjuge: precisaConjuge ? (nomeConjuge || 'desconhecido') : nomeConjuge,
    nacionalidade_texto: nacionalidade,
    data_nascimento: nascimento,
    filiacao: filiacaoNormalizada,
    tipo_trabalho_texto: cleanText(solar.tipo_trabalho) || 'Beneficiario',
    profissao: cleanText(solar.representante_ocupacao),
    rg_numero: cleanText(solar.rg_numero || solar.rg_executado || solar.assistido_rg),
    rg_orgao: cleanText(solar.rg_orgao || solar.emissor_rg_executado || solar.assistido_rg_orgao),
    rg_data_expedicao: cleanText(solar.rg_data_expedicao || solar.assistido_rg_data_expedicao),
    certidao_tipo: cleanText(solar.certidao_tipo),
    certidao_numero: cleanText(solar.certidao_numero),
    raca: cleanText(solar.raca),
    escolaridade: cleanText(solar.escolaridade),
    cep: onlyDigits(
      solar.cep || solar.endereco_cep || solar.requerente_cep || solar.cep_assistido ||
      endereco.cep || endereco.CEP || endereco.codigo_postal
    ),
    logradouro: firstClean(
      solar.logradouro, solar.endereco_logradouro, solar.requerente_logradouro, solar.rua, solar.endereco_rua,
      endereco.logradouro, endereco.endereco, endereco.rua, endereco.address, endereco.street
    ),
    numero: firstClean(
      solar.numero, solar.endereco_numero, solar.requerente_numero, solar.numero_endereco,
      endereco.numero, endereco.num, endereco.number
    ),
    complemento: firstClean(
      solar.complemento, solar.endereco_complemento, solar.requerente_complemento,
      endereco.complemento, endereco.complement
    ),
    bairro: firstClean(
      solar.bairro, solar.endereco_bairro, solar.requerente_bairro,
      endereco.bairro, endereco.district
    ),
    municipio: firstClean(
      solar.municipio, solar.endereco_municipio_id, solar.municipio_id, solar.cidade_id,
      endereco.municipio_id, endereco.cidade_id, endereco.municipio, endereco.cidade, endereco.city
    ),
    municipio_nome: firstClean(
      solar.municipio_nome, solar.endereco_municipio_nome, solar.cidade, solar.cidade_nome,
      endereco.municipio_nome, endereco.cidade_nome, endereco.municipio, endereco.cidade, endereco.city
    ),
    estado: firstClean(
      solar.estado, solar.endereco_estado_id, solar.estado_id, solar.uf, solar.endereco_uf,
      endereco.estado_id, endereco.uf_id, endereco.estado, endereco.uf, endereco.state
    ),
    estado_nome: firstClean(
      solar.estado_nome, solar.endereco_estado_nome, solar.uf_nome,
      endereco.estado_nome, endereco.uf_nome, endereco.estado, endereco.uf, endereco.state
    ),
    tipo_area: firstClean(solar.tipo_area, solar.endereco_tipo_area, endereco.tipo_area),
    tipo_endereco: firstClean(solar.tipo_endereco, solar.endereco_tipo, endereco.tipo_endereco, endereco.tipo),
    moradia_tipo: cleanText(solar.moradia_tipo),
    moradia_num_comodos: cleanText(solar.moradia_num_comodos),
    renda_numero_membros: cleanText(solar.renda_numero_membros),
    renda_numero_membros_economicamente_ativos: cleanText(solar.renda_numero_membros_economicamente_ativos),
    renda_individual: cleanText(solar.renda_individual),
    renda_familiar: cleanText(solar.renda_familiar),
    tem_plano_saude: cleanText(solar.tem_plano_saude),
    isento_ir: cleanText(solar.isento_ir),
    previdencia: cleanText(solar.previdencia),
    processo: extractProcesso(root, solar),
    observacoes: buildObservacoes(root, solar),
    bruto: root
  };

  const faltas = [];
  if(normalized.cpf.length !== 11) faltas.push('CPF com 11 digitos');
  if(!normalized.nome) faltas.push('nome');
  if(!normalized.data_nascimento) faltas.push('data de nascimento');
  if(faltas.length) throw new Error('Campos ausentes: ' + faltas.join(', '));
  return normalized;
}

function guessDocKind(file){
  const name = (file.webkitRelativePath || file.name).toLowerCase();
  const type = String(file.type || '').toLowerCase();
  if(name.endsWith('.json')) return 'json';
  if(name.endsWith('.pdf') || type === 'application/pdf') return 'pdf';
  if(type.startsWith('image/') || /\.(png|jpe?g|webp|gif)$/i.test(name)) return 'imagem';
  if(/\.(docx?|odt|rtf)$/i.test(name)) return 'documento_texto';
  if(/\.(xlsx?|csv)$/i.test(name)) return 'planilha';
  if(name.endsWith('.zip') || type === 'application/zip') return 'zip';
  if(name.includes('rg')) return 'rg';
  if(name.includes('cpf')) return 'cpf';
  if(name.includes('resid')) return 'comprovante_residencia';
  if(name.includes('certidao') || name.includes('certidão')) return 'certidao';
  if(name.includes('relato')) return 'relato';
  return 'documento';
}

function renderProject(){
  if(!currentProject){
    $('project').textContent = 'Nenhum atendimento carregado.';
    return;
  }
  const docs = currentProject.files.filter(f => f.kind !== 'json');
  const endereco = currentProject.normalized || {};
  const enderecoResumo = [
    endereco.cep || endereco.logradouro || endereco.bairro || endereco.municipio_nome || endereco.municipio
      ? `Endereco: ${[
          endereco.logradouro,
          endereco.numero && `n ${endereco.numero}`,
          endereco.bairro,
          endereco.municipio_nome || endereco.municipio,
          endereco.estado_nome || endereco.estado,
          endereco.cep && `CEP ${endereco.cep}`
        ].filter(Boolean).join(' - ')}`
      : 'Endereco: nao encontrado no JSON carregado'
  ];
  $('project').textContent = [
    `JSON: ${currentProject.jsonPath}`,
    `CPF: ${currentProject.normalized.cpf_formatado || currentProject.normalized.cpf}`,
    `Nome: ${currentProject.normalized.nome}`,
    `Caso: ${currentProject.normalized.caso?.protocolo || '-'}`,
    ...enderecoResumo,
    `Arquivos anexos: ${docs.length}`,
    ...docs.slice(0, 12).map(f => `- ${f.path} (${f.kind}, ${f.size} bytes)`),
    docs.length > 12 ? `- ... mais ${docs.length - 12} arquivo(s)` : ''
  ].filter(Boolean).join('\n');
}

function projectSummary(project){
  const files = project.files || [];
  const docs = files.filter(f => f.kind !== 'json');
  return {
    jsonPath: project.jsonPath,
    cpf: project.normalized?.cpf_formatado || project.normalized?.cpf || '',
    nome: project.normalized?.nome || '',
    caso: project.normalized?.caso?.protocolo || null,
    anexos: docs.length,
    anexosBytes: docs.reduce((sum, f) => sum + (Number(f.size) || 0), 0),
    amostra: docs.slice(0, MAX_LOG_FILES).map(f => ({
      path: f.path,
      kind: f.kind,
      size: f.size
    }))
  };
}

function persistableProject(project){
  return {
    jsonPath: project.jsonPath,
    normalized: project.normalized,
    files: (project.files || []).slice(0, MAX_LISTED_FILES)
  };
}

async function loadFromText(text, path = 'texto colado'){
  const raw = extractJson(text);
  const normalized = normalize(raw);
  currentProject = {
    jsonPath: path,
    raw,
    normalized,
    files: [{ path, name: path.split('/').pop(), kind: 'json', size: text.length }]
  };
  await api.storage.local.set({ solarProject: persistableProject(currentProject), solarAssistidoNormalized: normalized });
  renderProject();
  log(projectSummary(currentProject), 'ok');
}

async function loadFolder(files){
  const fileList = files || [];
  const totalFiles = fileList.length || 0;
  if(!totalFiles) throw new Error('Nenhum arquivo selecionado.');
  if(totalFiles > MAX_LISTED_FILES){
    log(`Foram selecionados ${totalFiles} arquivos. Vou carregar os dados principais e limitar a listagem persistida a ${MAX_LISTED_FILES} itens para evitar travamento.`);
  }

  const listed = [];
  const uploadCandidates = [];
  let firstJson = null;
  let atendimentoJson = null;
  for(let i = 0; i < totalFiles; i++){
    const f = fileList[i];
    const path = f.webkitRelativePath || f.name;
    if(listed.length < MAX_LISTED_FILES) listed.push(f);
    if(uploadCandidates.length < MAX_UPLOAD_FILES && guessDocKind(f) !== 'json') uploadCandidates.push(f);
    if(/\.json$/i.test(f.name)){
      if(!firstJson) firstJson = f;
      if(f.name.toLowerCase() === 'atendimento.json' || /(^|\/)atendimento\.json$/i.test(path)) atendimentoJson = f;
    }
  }

  const main = atendimentoJson || firstJson;
  if(!main) throw new Error('Selecione pelo menos um arquivo .json, preferencialmente o atendimento.json.');

  const text = await main.text();
  const raw = extractJson(text);
  const normalized = normalize(raw);
  currentProject = {
    jsonPath: main.webkitRelativePath || main.name,
    raw,
    normalized,
    files: listed.map(f => ({
      path: f.webkitRelativePath || f.name,
      name: f.name,
      kind: guessDocKind(f),
      type: f.type,
      size: f.size
    }))
  };
  selectedFiles = uploadCandidates;
  await api.storage.local.set({ solarProject: persistableProject(currentProject), solarAssistidoNormalized: normalized });
  renderProject();
  const summary = projectSummary(currentProject);
  summary.totalArquivosSelecionados = totalFiles;
  summary.anexosDisponiveisParaEnvio = selectedFiles.length;
  if(totalFiles > MAX_LISTED_FILES) summary.aviso = 'Os arquivos foram carregados em modo leve. Se precisar enviar anexos que nao apareceram, selecione menos arquivos.';
  log(summary, 'ok');
}

function readFileAsDataUrl(file){
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('Falha ao ler arquivo.'));
    reader.readAsDataURL(file);
  });
}

async function buildUploadPayload(){
  const docs = selectedFiles.filter(f => guessDocKind(f) !== 'json');
  if(!docs.length) throw new Error('Nenhum anexo esta disponivel em memoria. Selecione novamente o JSON junto com os documentos.');
  if(docs.length > MAX_UPLOAD_FILES){
    throw new Error(`Foram selecionados ${docs.length} anexos. Para evitar fechar o navegador, envie no maximo ${MAX_UPLOAD_FILES} arquivos por vez.`);
  }
  const totalBytes = docs.reduce((sum, f) => sum + (Number(f.size) || 0), 0);
  if(totalBytes > MAX_UPLOAD_TOTAL_BYTES){
    throw new Error(`Os anexos somam ${(totalBytes / 1024 / 1024).toFixed(1)} MB. Para evitar travamento, reduza para ate ${(MAX_UPLOAD_TOTAL_BYTES / 1024 / 1024).toFixed(0)} MB por envio.`);
  }
  const payload = [];
  for(const file of docs){
    payload.push({
      name: file.name,
      path: file.webkitRelativePath || file.name,
      type: file.type || 'application/octet-stream',
      size: file.size,
      kind: guessDocKind(file),
      dataUrl: await readFileAsDataUrl(file)
    });
  }
  return payload;
}

async function getProject(){
  if(currentProject) return currentProject;
  const st = await api.storage.local.get(['solarProject', 'solarAssistidoNormalized']);
  if(st.solarProject){
    currentProject = st.solarProject;
    lastAssistidoId = st.solarLastAssistidoId || '';
    renderProject();
    return currentProject;
  }
  throw new Error('Selecione o atendimento.json junto com os documentos.');
}

$('folder').addEventListener('change', async (e) => {
  try {
    await loadFolder(e.target.files);
  } catch(e) {
    log('Erro ao carregar arquivos: ' + e.message, 'bad');
  }
});

$('executar').onclick = async () => {
  try {
    const project = await getProject();
    log('Iniciando automacao completa do assistido...', '');
    appendLog('1. Consultando CPF e abrindo cadastro quando necessario.');
    const consulta = await sendBg({ type: 'BG_CONSULTAR_CPF_E_ABRIR', cpf: project.normalized.cpf }, 45000);
    if(!consulta.ok || consulta.existe){
      log({ ok: !!consulta.ok, consulta }, consulta.ok ? 'ok' : 'bad');
      return;
    }

    appendLog('2. Aguardando a tela de cadastro carregar.');
    await sleep(1800);

    appendLog('3. Preenchendo aba Basico.');
    const preenchimento = await sendBg({ type: 'BG_PREENCHER_BASICO', data: project.normalized }, 90000);
    const resultado = { ok: !!preenchimento.ok, consulta, preenchimento };
    if(!preenchimento.ok){
      log(resultado, 'bad');
      return;
    }

    appendLog('4. Tentando salvar assistido automaticamente.');
    resultado.salvamento = await sendBg({ type: 'BG_SALVAR_ASSISTIDO' }, 90000);
    resultado.ok = !!resultado.salvamento.ok;
    if(resultado.ok && resultado.salvamento.assistido_id){
      lastAssistidoId = resultado.salvamento.assistido_id;
      await api.storage.local.set({ solarLastAssistidoId: lastAssistidoId });
      appendLog('5. Abrindo cadastro salvo na aba de documentos pessoais.');
      resultado.proximaTela = await sendBg({
        type: 'BG_ABRIR_URL_SOLAR',
        path: `/assistido/editar/${lastAssistidoId}/0/`,
        hash: 'documentos'
      }, 30000);
    }

    log(resultado, resultado.ok ? 'ok' : 'bad');
  } catch(e) {
    log('Erro: ' + e.message, 'bad');
  }
};

$('injetar').onclick = async () => {
  try {
    const project = await getProject();
    const st = await api.storage.local.get(['solarLastAssistidoId']);
    const assistidoId = lastAssistidoId || st.solarLastAssistidoId || '';
    const files = await buildUploadPayload();
    const resp = await sendBg({
      type: 'BG_UPLOAD_DOCUMENTOS_ASSISTIDO',
      files,
      assistidoId,
      data: project.normalized
    }, 120000);
    log(resp, resp?.ok ? 'ok' : 'bad');
  } catch(e) {
    log('Erro: ' + e.message, 'bad');
  }
};

$('criarAtendimento').onclick = async () => {
  try {
    const st = await api.storage.local.get(['solarLastAssistidoId']);
    const assistidoId = lastAssistidoId || st.solarLastAssistidoId || '';
    if(!assistidoId) throw new Error('Nenhum assistido salvo encontrado. Execute a automacao do assistido primeiro.');
    const resp = await sendBg({
      type: 'BG_ABRIR_URL_SOLAR',
      path: '/atendimento/listar/',
      query: { pessoa_id: assistidoId }
    }, 30000);
    log(resp, resp?.ok ? 'ok' : 'bad');
  } catch(e) {
    log('Erro: ' + e.message, 'bad');
  }
};

(async () => {
  const st = await api.storage.local.get(['solarProject', 'solarAssistidoNormalized', 'solarLastAssistidoId']);
  if(st.solarProject){
    currentProject = st.solarProject;
    lastAssistidoId = st.solarLastAssistidoId || '';
    renderProject();
    log(currentProject, 'ok');
  }
})();
