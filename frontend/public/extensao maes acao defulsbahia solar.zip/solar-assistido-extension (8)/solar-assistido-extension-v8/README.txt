SOLAR - Cadastro robusto de assistido v0.8

Correção principal:
- Removi completamente o bloqueio declarativeNetRequest do Jcrop.gif.
- O erro de console do Jcrop.gif é do próprio SOLAR, mas a versão anterior tentava bloquear o recurso e isso podia gerar mensagem “Blocked”.

Fluxo:
1. Normalizar JSON.
2. Consultar CPF e abrir cadastro se não existir.
3. Preencher apenas aba Básico.
4. Validar campos obrigatórios.
5. Salvar manualmente no SOLAR.

Importante:
Se o console continuar exibindo “Refused to execute script ... Jcrop.gif”, ignore. Essa mensagem vem do HTML do SOLAR, não da extensão.
