# Explicacao detalhada da extensao SOLAR Assistido

## 1. Objetivo da extensao

Esta extensao foi criada para auxiliar o cadastro de assistidos no sistema SOLAR da Defensoria Publica da Bahia.

O objetivo pratico da versao atual e reduzir o trabalho manual de copiar dados de um JSON, consultar se o CPF ja existe no SOLAR e preencher a aba inicial de cadastro do assistido, chamada aba **Basico**.

A extensao nao substitui totalmente a operacao humana no SOLAR. Ela organiza os dados, automatiza parte do preenchimento e faz validacoes preliminares, mas o usuario ainda deve conferir as informacoes e salvar manualmente dentro do proprio SOLAR.

## 2. Estado atual do projeto

Apesar do documento `conhecimento.md` descrever uma arquitetura futura baseada em **Side Panel**, o codigo existente no repositorio esta implementado como uma extensao Manifest V3 com **popup**.

Arquivos atuais:

```text
manifest.json
background.js
content.js
popup.html
popup.js
README.txt
exemplo-assistido.json
conhecimento.md
```

Na versao atual, o fluxo principal acontece assim:

1. O usuario abre o SOLAR em uma aba ja autenticada.
2. O usuario abre o popup da extensao.
3. Cola ou carrega um JSON com dados do assistido.
4. A extensao normaliza os dados.
5. A extensao consulta o CPF no SOLAR.
6. Se o CPF nao existir, a extensao abre a tela de cadastro.
7. O usuario aguarda a tela carregar.
8. A extensao preenche a aba Basico.
9. A extensao valida campos obrigatorios.
10. O usuario confere e salva manualmente no SOLAR.

## 3. Diferenca entre a versao atual e a arquitetura planejada

O arquivo `conhecimento.md` define uma direcao arquitetural mais robusta:

```text
Side Panel + engine interno + execucao dentro da pagina do SOLAR
```

Essa direcao e importante porque o popup do navegador tem limitacoes para fluxos longos:

- pode perder estado quando fechado;
- tem pouco espaco visual;
- nao e ideal para upload de multiplos documentos;
- nao e adequado para um wizard de varias etapas;
- dificulta acompanhamento de execucao longa.

O Side Panel resolveria esses pontos ao funcionar como uma barra lateral fixa, mantendo estado, exibindo etapas e permitindo interacao continua com a pagina do SOLAR.

Entretanto, o codigo atualmente implementado ainda esta no modelo:

```text
popup.html / popup.js
  -> background.js
    -> content.js
      -> pagina do SOLAR
```

Portanto, esta documentacao descreve primeiro a extensao real existente e, ao final, explica como ela deve evoluir para a arquitetura com Side Panel.

## 4. Manifest da extensao

O arquivo `manifest.json` declara a extensao como Manifest V3.

Principais configuracoes:

```json
{
  "manifest_version": 3,
  "name": "SOLAR - Cadastro robusto de assistido v0.8",
  "version": "0.8.0"
}
```

A extensao solicita as seguintes permissoes:

- `activeTab`: permite atuar sobre a aba ativa do navegador.
- `scripting`: permite injetar scripts na pagina quando necessario.
- `storage`: permite armazenar localmente os dados normalizados.
- `tabs`: permite consultar e atualizar a aba ativa.

Ela tambem limita sua atuacao ao dominio:

```text
https://solar.defensoria.ba.def.br/*
```

Isso significa que a automacao foi pensada especificamente para paginas internas do SOLAR.

## 5. Interface atual: popup

A interface visual atual esta em `popup.html`.

Ela possui:

- campo para upload de arquivo `.json` ou `.txt`;
- area de texto para colar JSON manualmente;
- campo obrigatorio para data de nascimento;
- campo obrigatorio para filiacao;
- botao para normalizar;
- botao para consultar CPF e abrir cadastro;
- botao para preencher a aba Basico;
- botao para validar campos obrigatorios;
- area de saida com logs e resultado das operacoes.

O popup trabalha como um painel simples de operacao. Ele nao executa diretamente a automacao dentro do SOLAR; ele envia mensagens para o `background.js`, que por sua vez conversa com o `content.js` injetado na pagina.

## 6. Entrada de dados

A extensao aceita um JSON com dados do assistido.

Exemplo simplificado:

```json
{
  "cpf": "11824627742",
  "nome": "Nome do Assistido",
  "telefone": "73999999999",
  "email_assistido": "email@exemplo.com",
  "assistido_estado_civil": "solteiro",
  "assistido_nacionalidade": "brasileira",
  "representante_nome": "Nome do Representante",
  "assistido_eh_incapaz": "sim"
}
```

O JSON pode vir com nomes de campos diferentes. O arquivo `popup.js` tenta reconhecer algumas variacoes, por exemplo:

- `cpf` ou `assistido_cpf`;
- `nome` ou `assistido_nome`;
- `email_assistido`, `email` ou `representante_email`;
- `telefone`, `assistido_telefone` ou `representante_telefone`;
- `filiacao`, `mae`, `nome_mae` ou `representante_nome`;
- `data_nascimento` ou `assistido_data_nascimento`;
- `assistido_estado_civil` ou `estado_civil`;
- `assistido_nacionalidade` ou `nacionalidade`.

Para endereco, o formato recomendado e enviar um objeto `endereco` dentro de `solar`:

```json
{
  "solar": {
    "cpf": "27886963024",
    "NOME": "MARA",
    "data_nascimento_assistido": "20/09/2025",
    "nome_mae_assistido": "MAE",
    "requerente_telefone": "(99) 99999-9999",
    "requerente_email": "dd@gmail.com",
    "endereco": {
      "cep": "45990280",
      "logradouro": "Rua Aguas Claras",
      "numero": "25",
      "complemento": "",
      "bairro": "Bela Vista",
      "municipio": "Teixeira de Freitas",
      "uf": "BA",
      "tipo_area": "urbana",
      "tipo_endereco": "residencial"
    }
  }
}
```

A extensao tambem aceita os campos de endereco soltos dentro de `solar`, usando nomes como:

- `cep`, `endereco_cep` ou `requerente_cep`;
- `logradouro`, `rua`, `endereco_logradouro` ou `requerente_logradouro`;
- `numero`, `endereco_numero` ou `requerente_numero`;
- `complemento`, `endereco_complemento` ou `requerente_complemento`;
- `bairro`, `endereco_bairro` ou `requerente_bairro`;
- `municipio`, `municipio_nome`, `cidade`, `cidade_nome`, `endereco_municipio_id` ou `endereco_municipio_nome`;
- `estado`, `estado_nome`, `uf`, `endereco_uf`, `endereco_estado_id` ou `endereco_estado_nome`.

Se o endereco vier em outro objeto aninhado, por exemplo `requerente.endereco`, `assistido.endereco` ou `pessoa.endereco`, a extensao tambem tenta localizar automaticamente um objeto que tenha CEP junto com logradouro, cidade/municipio ou bairro.

Campos mais importantes para o SOLAR:

- `cep`: preferencialmente com 8 digitos. Quando informado, a extensao consulta `/endereco/get_by_cep/CEP/` e completa municipio, bairro, logradouro e estado quando o SOLAR ja conhece o CEP.
- `numero`: numero do imovel. O CEP nao preenche esse campo.
- `municipio`: pode ser o codigo IBGE usado pelo SOLAR, como `2931350`, ou o nome do municipio. Se vier nome e houver estado, a extensao tenta localizar o ID em `/estado/ESTADO/municipios/`.
- `uf` ou `estado`: pode vir como `BA`, `Bahia` ou `29`.
- `tipo_area`: aceita `urbana`/`0` ou `rural`/`1`; se faltar, usa urbana.
- `tipo_endereco`: aceita `residencial`/`10`, `comercial`/`20`, `correspondencia`/`30` ou `alternativo`/`40`; se faltar, usa residencial.

Quando o JSON nao traz data de nascimento ou filiacao, o popup permite informar esses dados manualmente antes da normalizacao.

## 7. Normalizacao dos dados

A normalizacao acontece em `popup.js`, na funcao `normalize`.

Essa etapa transforma dados soltos do JSON em um objeto padronizado para a extensao.

O objeto normalizado inclui:

```js
{
  cpf,
  cpf_formatado,
  nome,
  email,
  telefone,
  telefone_formatado,
  estado_civil_texto,
  nacionalidade_texto,
  data_nascimento,
  filiacao,
  tipo_trabalho_texto,
  profissao,
  observacoes
}
```

Principais tratamentos feitos:

- remove caracteres nao numericos do CPF;
- aplica mascara de CPF quando ha 11 digitos;
- remove caracteres nao numericos do telefone;
- aplica mascara de telefone quando possivel;
- remove acentos do nome;
- converte nome e filiacao para letras maiusculas;
- junta informacoes complementares em `observacoes`;
- valida se CPF, nome, data de nascimento e filiacao existem.

Se algum dado essencial estiver ausente, a extensao mostra erro e interrompe a operacao.

Campos obrigatorios da normalizacao:

- CPF com 11 digitos;
- nome;
- data de nascimento;
- filiacao.

## 8. Persistencia local

Depois da normalizacao, os dados sao salvos no armazenamento local da extensao:

```js
chrome.storage.local.set({
  solarAssistidoNormalized: normalized
});
```

Isso permite que o dado normalizado continue disponivel quando o usuario clica em outro botao do popup, como preencher ou validar.

Na arquitetura futura com Side Panel, esse conceito continua importante, mas o estado provavelmente ficara mais completo, incluindo:

- etapa atual;
- status de cada etapa;
- documentos carregados;
- retorno da consulta de CPF;
- identificador do assistido criado;
- identificador do atendimento criado;
- logs de execucao.

## 9. Papel do background.js

O `background.js` funciona como intermediario entre o popup e a pagina do SOLAR.

Ele e responsavel por:

- localizar a aba ativa;
- verificar se a aba ativa pertence ao SOLAR;
- garantir que o `content.js` esta carregado;
- enviar mensagens para o `content.js`;
- abrir a URL de cadastro quando o CPF nao existe;
- devolver respostas estruturadas para o popup.

A extensao so aceita operar se a aba ativa comecar com:

```text
https://solar.defensoria.ba.def.br/
```

Se o usuario estiver em outro site ou em uma pagina fora do SOLAR, o background retorna erro.

## 10. Garantia de injecao do content script

O `background.js` possui uma rotina chamada `ensureContentScript`.

Ela primeiro tenta enviar um ping para a pagina:

```js
{ type: "SOLAR_PING" }
```

Se o `content.js` responder, a extensao segue normalmente.

Se nao responder, o background injeta o arquivo:

```js
chrome.scripting.executeScript({
  target: { tabId },
  files: ["content.js"]
});
```

Depois disso, ele tenta novamente por alguns ciclos. Se ainda nao conseguir contato, mostra uma mensagem orientando recarregar a pagina do SOLAR.

Esse mecanismo evita o erro comum:

```text
Receiving end does not exist
```

Esse erro acontece quando a extensao tenta enviar mensagem para uma pagina onde o content script ainda nao esta ativo.

## 11. Consulta de CPF

A consulta de CPF e iniciada pelo botao:

```text
2. Consultar CPF e abrir cadastro
```

O popup envia ao background:

```js
{
  type: "BG_CONSULTAR_CPF_E_ABRIR",
  cpf: n.cpf
}
```

O background repassa ao content script:

```js
{
  type: "SOLAR_CONSULTAR_CPF",
  cpf: msg.cpf
}
```

Dentro da pagina do SOLAR, o `content.js` chama o endpoint:

```text
/assistido/cpf/existe/
```

A requisicao e feita por `fetch` com:

- metodo `POST`;
- `credentials: "same-origin"`;
- cabecalho `X-CSRFToken`;
- corpo JSON contendo o CPF.

Esse detalhe e fundamental: a requisicao e feita dentro do contexto da propria pagina do SOLAR, usando a sessao ja autenticada do usuario.

## 12. Por que a consulta precisa acontecer na pagina do SOLAR

O SOLAR depende de sessao, cookies, CSRF token e contexto de origem.

Por isso, chamadas sensiveis como consultar CPF, preencher cadastro e futuramente anexar documentos nao devem acontecer diretamente no background da extensao.

O background nao deve tentar "imitar" o usuario fora da pagina. Ele apenas coordena.

A execucao real deve acontecer no `content.js`, porque ele roda dentro da aba do SOLAR e consegue acessar:

- DOM da pagina;
- cookies de mesma origem via requisicoes da propria pagina;
- token CSRF;
- contexto Angular do formulario;
- elementos visuais do cadastro.

Essa e uma restricao critica tambem para a versao futura com Side Panel.

## 13. Abertura da tela de cadastro

Se a consulta indicar que o CPF ja existe, a extensao interrompe o fluxo e informa o usuario.

Se o CPF nao existe, o background monta a URL:

```text
https://solar.defensoria.ba.def.br/assistido/editar/0/0/?next=/atendimento/listar/&nome=&cpf=CPF#basico
```

Em seguida atualiza a aba ativa:

```js
chrome.tabs.update(tab.id, { url });
```

Isso abre diretamente a tela de cadastro de assistido na aba Basico, com o CPF na URL.

## 14. Preenchimento da aba Basico

O preenchimento e feito pelo `content.js`, na funcao `preencherBasico`.

Antes de preencher, a extensao aguarda a tela ficar pronta:

- verifica se existe `#AssistidoForm`;
- verifica se existe `#id_cpf`;
- verifica se o Angular esta disponivel;
- tenta obter o escopo Angular da tela.

Se a tela nao estiver pronta, retorna erro pedindo para aguardar mais alguns segundos.

Depois disso, a extensao:

1. clica na aba Basico, se necessario;
2. obtem o escopo Angular;
3. atualiza `scope.pessoa`;
4. dispara eventos nativos nos campos HTML;
5. tenta selecionar valores em campos de lista;
6. chama validacao da pagina quando disponivel;
7. retorna o resultado de `validar`.

## 15. Integracao com Angular do SOLAR

O SOLAR usa Angular em partes da tela de cadastro.

Por isso, preencher somente o valor visual dos inputs nao e suficiente. O sistema precisa que o modelo Angular tambem seja atualizado.

A extensao faz isso com:

```js
scope.$apply(function() {
  const p = scope.pessoa;
  p.cpf = onlyDigits(data.cpf);
  p.nome = data.nome || "";
  p.email = data.email || "";
  p.data_nascimento = data.data_nascimento || "";
});
```

Tambem preenche estruturas internas como:

- `p.filiacao`;
- `p.telefones`;
- `p.estado_civil`;
- `p.nacionalidade`;
- `p.tipo_trabalho`;
- campos socioeconomicos basicos.

Essa dupla abordagem e importante:

- atualizar o Angular garante que o SOLAR reconheca os dados;
- atualizar o DOM garante que o usuario veja os campos preenchidos.

## 16. Campos preenchidos atualmente

A versao atual foca na aba Basico.

Campos principais:

- CPF;
- nome;
- filiacao;
- data de nascimento;
- email;
- telefone;
- estado civil;
- nacionalidade;
- tipo de trabalho;
- alguns campos socioeconomicos padrao.

Valores padrao usados em alguns casos:

- filiacao: `DESCONHECIDO`, se nao informada;
- numero de membros: `1`;
- plano de saude: `0`;
- isento de IR: `1`;
- previdencia: `0`;
- tipo de trabalho: tenta usar `Beneficiario` quando os dados indicam beneficio ou relato.

## 17. Validacao

A validacao acontece no `content.js`, na funcao `validar`.

Ela verifica duas camadas:

1. Estado do formulario Angular (`scope.AssistidoForm`).
2. Campos obrigatorios minimos no objeto `scope.pessoa`.

Campos obrigatorios verificados:

- CPF;
- nome;
- data de nascimento;
- filiacao;
- telefone.

O retorno da validacao inclui:

```js
{
  ok,
  angularInvalid,
  faltas,
  pessoaResumo
}
```

Isso permite que o popup mostre se a tela esta pronta para conferencia e salvamento manual.

## 18. Mensageria interna

A extensao usa `chrome.runtime.sendMessage` e `chrome.tabs.sendMessage`.

Mensagens principais do popup para o background:

```text
BG_CONSULTAR_CPF_E_ABRIR
BG_PREENCHER_BASICO
BG_VALIDAR_PAGINA
BG_INJETAR
```

Mensagens principais do background para o content script:

```text
SOLAR_PING
SOLAR_CONSULTAR_CPF
SOLAR_PREENCHER_BASICO
SOLAR_VALIDAR
```

Essa separacao e correta porque o popup nao deve depender diretamente da pagina. O background centraliza a escolha da aba e o content script executa dentro do SOLAR.

## 19. Limites da versao atual

A versao atual nao faz:

- criacao completa de atendimento;
- upload de documentos pessoais;
- upload de documentos de atendimento;
- salvamento automatico final;
- fluxo multi-etapas persistente;
- drag and drop de arquivos;
- controle visual avancado de etapas;
- Side Panel;
- fallback especifico para Firefox.

Ela tambem depende de detalhes internos da tela do SOLAR, como:

- seletores HTML;
- nomes de campos;
- estrutura Angular;
- endpoint `/assistido/cpf/existe/`;
- existencia de `scope.pessoa`.

Se o SOLAR mudar sua tela ou seus nomes internos, partes da extensao podem precisar de ajuste.

## 20. Erros comuns

### Aba ativa fora do SOLAR

Mensagem esperada:

```text
Abra qualquer pagina interna do SOLAR ja logada antes de executar.
```

Motivo: a extensao so opera no dominio autorizado.

### Content script nao conectado

Mensagem possivel:

```text
Nao consegui conectar o script da extensao a pagina do SOLAR.
```

Motivo: o script ainda nao foi injetado ou a pagina precisa ser recarregada.

### Angular ainda nao carregou

Mensagem possivel:

```text
Angular ainda nao carregou. Aguarde a pagina terminar de abrir.
```

Motivo: a tela do SOLAR ainda nao inicializou completamente.

### Tela de cadastro nao pronta

Mensagem possivel:

```text
A tela de cadastro nao ficou pronta a tempo.
```

Motivo: o usuario clicou em preencher antes da tela `/assistido/editar/` estar carregada.

### CPF ja cadastrado

Nesse caso a extensao interrompe o cadastro para evitar duplicidade.

## 21. Observacao sobre erro Jcrop.gif

O `README.txt` informa que a versao atual removeu bloqueios relacionados ao recurso `Jcrop.gif`.

Se o console do navegador mostrar erro semelhante a:

```text
Refused to execute script ... Jcrop.gif
```

isso vem do proprio HTML do SOLAR e nao deve ser tratado pela extensao como causa principal de falha.

A versao atual evita bloquear recursos do SOLAR para nao gerar mensagens artificiais de "Blocked".

## 22. Arquitetura futura com Side Panel

O documento `conhecimento.md` define que a extensao ideal deve deixar de ser popup e passar a ser Side Panel.

Estrutura sugerida:

```text
manifest.json
background.js
content.js
injected.js

sidepanel/
  sidepanel.html
  sidepanel.js
  sidepanel.css

core/
  parser.js
  normalizer.js
  validator.js
  solar-api.js
  assistido.js
  atendimento.js
  documentos.js

utils/
  dom.js
  events.js
  csrf.js
  file-handler.js

config.js
```

Essa arquitetura separa melhor as responsabilidades.

## 23. Responsabilidades na arquitetura futura

### sidepanel

Responsavel pela interface fixa:

- upload de JSON;
- upload de documentos;
- exibicao dos dados normalizados;
- wizard de etapas;
- logs;
- botoes de execucao;
- status de sucesso ou erro.

### background

Responsavel por coordenar:

- aba ativa do SOLAR;
- injecao de scripts;
- roteamento de mensagens;
- abertura de URLs;
- persistencia global de estado.

### content script

Responsavel por executar na pagina:

- consultar CPF;
- preencher formularios;
- interagir com Angular;
- anexar documentos;
- validar telas;
- capturar IDs criados.

### core

Responsavel por regras de negocio:

- parse do JSON;
- normalizacao;
- validacao;
- operacoes de assistido;
- operacoes de atendimento;
- operacoes de documentos;
- chamadas ao SOLAR feitas no contexto correto.

### utils

Responsavel por utilitarios:

- seletores DOM;
- eventos;
- CSRF;
- arquivos;
- esperas e retries.

## 24. Fluxo futuro ideal

O fluxo completo esperado para a versao final seria:

1. Abrir SOLAR autenticado.
2. Abrir Side Panel da extensao.
3. Carregar JSON do assistido.
4. Normalizar e validar dados.
5. Consultar CPF no SOLAR.
6. Se CPF existir, interromper ou abrir cadastro existente.
7. Se CPF nao existir, abrir cadastro novo.
8. Preencher dados basicos.
9. Salvar assistido ou orientar salvamento assistido.
10. Capturar `assistido_id`.
11. Anexar documentos pessoais.
12. Criar atendimento.
13. Capturar `atendimento_id`.
14. Anexar documentos do atendimento.
15. Mostrar resumo final da operacao.

## 25. Documentos em duas camadas

O conhecimento do projeto indica que documentos devem ser tratados em duas camadas:

### Documentos pessoais

Dependem de:

```text
assistido_id
```

Exemplos:

- RG;
- CPF;
- comprovante de residencia;
- certidao;
- documentos pessoais do representante.

### Documentos de atendimento

Dependem de:

```text
atendimento_id
```

Exemplos:

- relato;
- comprovantes do caso;
- documentos processuais;
- anexos especificos da demanda.

Essa separacao e importante porque anexar um documento no lugar errado pode dificultar sua localizacao dentro do SOLAR.

## 26. Por que o Side Panel e melhor para documentos

Upload de documentos exige mais estado e mais espaco de interface.

Um Side Panel permite:

- arrastar e soltar arquivos;
- listar documentos carregados;
- classificar cada arquivo por tipo;
- associar arquivo a assistido ou atendimento;
- mostrar progresso de upload;
- exibir erros por arquivo;
- manter o estado mesmo durante navegacao entre paginas do SOLAR.

O popup atual nao e ideal para isso, porque pode fechar e perder contexto visual durante uma operacao longa.

## 27. Regra critica: execucao sempre dentro do SOLAR

Mesmo na arquitetura futura, a regra principal deve continuar:

```text
Cadastro, consulta e upload devem ocorrer dentro da aba do SOLAR.
```

O Side Panel pode controlar o fluxo, mas nao deve fazer diretamente operacoes sensiveis fora da pagina.

Modelo correto:

```text
Side Panel
  -> Background
    -> Content Script
      -> SOLAR
```

O background e o painel organizam. O content script executa.

## 28. Papel do usuario

A extensao foi pensada para apoiar o operador, nao para retirar a conferencia humana.

O usuario ainda deve:

- estar logado no SOLAR;
- abrir uma pagina interna do SOLAR;
- conferir os dados preenchidos;
- verificar mensagens de validacao;
- salvar manualmente quando a versao atual exigir;
- corrigir dados incompletos ou inconsistentes;
- decidir o que fazer quando CPF ja existe.

## 29. Riscos tecnicos

Principais riscos:

- mudanca no HTML do SOLAR;
- mudanca no Angular da tela;
- mudanca no endpoint de consulta de CPF;
- diferencas de permissao entre usuarios do SOLAR;
- sessao expirada;
- token CSRF ausente;
- popup fechando antes do termino do fluxo;
- dados de entrada incompletos;
- duplicidade de assistido;
- upload de documento em camada errada.

A evolucao para Side Panel reduz alguns riscos operacionais, mas nao elimina a dependencia da estrutura interna do SOLAR.

## 30. Resumo executivo

A extensao atual e uma ferramenta Manifest V3 para Chrome/Edge/Brave que:

- recebe JSON de um assistido;
- normaliza dados;
- consulta CPF no SOLAR;
- evita cadastro duplicado quando CPF ja existe;
- abre a tela de cadastro quando CPF nao existe;
- preenche a aba Basico;
- valida campos obrigatorios;
- deixa o salvamento final sob controle do usuario.

A evolucao planejada transforma essa ferramenta em um centro lateral de operacao do SOLAR, com Side Panel, wizard de etapas, upload de documentos e fluxo completo de assistido, atendimento e anexos.

O ponto mais importante da arquitetura e manter a execucao real dentro da pagina do SOLAR, usando o content script, porque e ali que existem sessao, CSRF, DOM e Angular necessarios para a automacao funcionar corretamente.
